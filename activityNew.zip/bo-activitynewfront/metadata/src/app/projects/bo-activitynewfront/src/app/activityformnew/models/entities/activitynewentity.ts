
import { Entity, NgField, NgObject, EntityList, NgList, NgDynamic, DynamicEntity } from '@farris/devkit';

export class ActivityNewEntity extends Entity {

    @NgField({
        originalDataField: 'ID',
        dataField: 'id',
        primary: true,
        initValue: '',
        path: 'ID',

        validRules: [
            {
                type: 'required',
            },
            {
                type: 'maxLength',
                constraints: [36],
            }
        ]
    })
    id: string;

    @NgField({
        originalDataField: 'Version',
        dataField: 'version',
        initValue: '0001-01-01T00:00:00',
        path: 'Version',
    })
    version: string;

    @NgField({
        originalDataField: 'Code',
        dataField: 'code',
        initValue: '',
        path: 'Code',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
            }
        ]
    })
    code: string;

    @NgField({
        originalDataField: 'Title',
        dataField: 'title',
        initValue: '',
        path: 'Title',

        validRules: [
            {
                type: 'maxLength',
                constraints: [1024],
            }
        ]
    })
    title: string;

    @NgField({
        originalDataField: 'Location',
        dataField: 'location',
        initValue: '',
        path: 'Location',

        validRules: [
            {
                type: 'maxLength',
                constraints: [1024],
            }
        ]
    })
    location: string;

    @NgField({
        originalDataField: 'GeoLng',
        dataField: 'geoLng',
        initValue: 0,
        path: 'GeoLng',
    })
    geoLng: any;

    @NgField({
        originalDataField: 'GeoLat',
        dataField: 'geoLat',
        initValue: 0,
        path: 'GeoLat',
    })
    geoLat: any;

    @NgField({
        originalDataField: 'UpdateInfo',
        dataField: 'updateInfo',
        initValue: '',
        path: 'UpdateInfo',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
            }
        ]
    })
    updateInfo: string;

}