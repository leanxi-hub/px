
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository, NgVariable } from '@farris/bef';
import { ActivityNewEntity } from './entities/activitynewentity';

import { ActivityNewProxy } from './activitynewproxy';

@Injectable()
@NgRepository({
    apiUrl: 'api/gsp/myapp/v1.0/activityformnew_frm',
    entityType: ActivityNewEntity
})
export class ActivityNewRepository extends BefRepository<ActivityNewEntity> {
    public name = 'ActivityNewRepository';

    public proxy: ActivityNewProxy;
    public paginationInfo = {
        ActivityNewEntity: {
            pageSize: 20,
        }
    };
    constructor(injector: Injector) {
        super(injector);
        this.proxy = injector.get(ActivityNewProxy, null);
    }
}