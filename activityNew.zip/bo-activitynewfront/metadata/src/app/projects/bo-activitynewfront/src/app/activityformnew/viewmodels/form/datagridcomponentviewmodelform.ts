
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm  } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: 'activityNew',
    enableValidate: false
})

@Injectable()
export class DataGridComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'code',
        name: "{{gridField_2ab0ad3d-b006-44aa-bac7-b5ec2086eb79_code}}",
        binding: 'code',
        updateOn: 'blur',
    })
    code: FormControl;

    @NgFormControl({
        id: 'title',
        name: "{{gridField_475ee71c-76a9-4d1e-bd62-2112ab7a29e5_title}}",
        binding: 'title',
        updateOn: 'blur',
    })
    title: FormControl;

    @NgFormControl({
        id: 'location',
        name: "{{gridField_46d598fa-a725-4b35-81d5-1a5f6ccd2aa0_location}}",
        binding: 'location',
        updateOn: 'blur',
    })
    location: FormControl;

}