import * as tslib_1 from "tslib";
import { Entity, NgField } from '@farris/devkit';
var ActivityNewEntity = /** @class */ (function (_super) {
    tslib_1.__extends(ActivityNewEntity, _super);
    function ActivityNewEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ActivityNewEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Version',
            dataField: 'version',
            initValue: '0001-01-01T00:00:00',
            path: 'Version',
        }),
        tslib_1.__metadata("design:type", String)
    ], ActivityNewEntity.prototype, "version", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Code',
            dataField: 'code',
            initValue: '',
            path: 'Code',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ActivityNewEntity.prototype, "code", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Title',
            dataField: 'title',
            initValue: '',
            path: 'Title',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [1024],
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ActivityNewEntity.prototype, "title", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Location',
            dataField: 'location',
            initValue: '',
            path: 'Location',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [1024],
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ActivityNewEntity.prototype, "location", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'GeoLng',
            dataField: 'geoLng',
            initValue: 0,
            path: 'GeoLng',
        }),
        tslib_1.__metadata("design:type", Object)
    ], ActivityNewEntity.prototype, "geoLng", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'GeoLat',
            dataField: 'geoLat',
            initValue: 0,
            path: 'GeoLat',
        }),
        tslib_1.__metadata("design:type", Object)
    ], ActivityNewEntity.prototype, "geoLat", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'UpdateInfo',
            dataField: 'updateInfo',
            initValue: '',
            path: 'UpdateInfo',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ActivityNewEntity.prototype, "updateInfo", void 0);
    return ActivityNewEntity;
}(Entity));
export { ActivityNewEntity };
