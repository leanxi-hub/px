import * as tslib_1 from "tslib";
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository } from '@farris/bef';
import { ActivityNewEntity } from './entities/activitynewentity';
import { ActivityNewProxy } from './activitynewproxy';
var ActivityNewRepository = /** @class */ (function (_super) {
    tslib_1.__extends(ActivityNewRepository, _super);
    function ActivityNewRepository(injector) {
        var _this = _super.call(this, injector) || this;
        _this.name = 'ActivityNewRepository';
        _this.paginationInfo = {
            ActivityNewEntity: {
                pageSize: 20,
            }
        };
        _this.proxy = injector.get(ActivityNewProxy, null);
        return _this;
    }
    ActivityNewRepository = tslib_1.__decorate([
        Injectable(),
        NgRepository({
            apiUrl: 'api/gsp/myapp/v1.0/activityformnew_frm',
            entityType: ActivityNewEntity
        }),
        tslib_1.__metadata("design:paramtypes", [Injector])
    ], ActivityNewRepository);
    return ActivityNewRepository;
}(BefRepository));
export { ActivityNewRepository };
