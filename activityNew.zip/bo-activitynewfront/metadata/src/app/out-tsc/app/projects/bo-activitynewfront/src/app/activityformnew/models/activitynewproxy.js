import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BefProxy, UriService } from '@farris/bef';
var ActivityNewProxy = /** @class */ (function (_super) {
    tslib_1.__extends(ActivityNewProxy, _super);
    function ActivityNewProxy(httpClient, uriService) {
        var _this = _super.call(this, httpClient, uriService) || this;
        _this.apiUrl = 'api/gsp/myapp/v1.0/activityformnew_frm';
        _this.baseUri = uriService.extendUri(_this.apiUrl);
        return _this;
    }
    ActivityNewProxy = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [HttpClient,
            UriService])
    ], ActivityNewProxy);
    return ActivityNewProxy;
}(BefProxy));
export { ActivityNewProxy };
