import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { UIState } from '@farris/devkit';
var DetailFormComponentViewmodelUIState = /** @class */ (function (_super) {
    tslib_1.__extends(DetailFormComponentViewmodelUIState, _super);
    function DetailFormComponentViewmodelUIState() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    DetailFormComponentViewmodelUIState = tslib_1.__decorate([
        Injectable()
    ], DetailFormComponentViewmodelUIState);
    return DetailFormComponentViewmodelUIState;
}(UIState));
export { DetailFormComponentViewmodelUIState };
