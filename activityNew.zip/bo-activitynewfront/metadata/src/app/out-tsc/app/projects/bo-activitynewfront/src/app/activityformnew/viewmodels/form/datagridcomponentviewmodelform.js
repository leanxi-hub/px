import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var DataGridComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DataGridComponentViewmodelForm, _super);
    function DataGridComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'code',
            name: "{{gridField_2ab0ad3d-b006-44aa-bac7-b5ec2086eb79_code}}",
            binding: 'code',
            updateOn: 'blur',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "code", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'title',
            name: "{{gridField_475ee71c-76a9-4d1e-bd62-2112ab7a29e5_title}}",
            binding: 'title',
            updateOn: 'blur',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "title", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'location',
            name: "{{gridField_46d598fa-a725-4b35-81d5-1a5f6ccd2aa0_location}}",
            binding: 'location',
            updateOn: 'blur',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "location", void 0);
    DataGridComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: 'activityNew',
            enableValidate: false
        }),
        Injectable()
    ], DataGridComponentViewmodelForm);
    return DataGridComponentViewmodelForm;
}(Form));
export { DataGridComponentViewmodelForm };
