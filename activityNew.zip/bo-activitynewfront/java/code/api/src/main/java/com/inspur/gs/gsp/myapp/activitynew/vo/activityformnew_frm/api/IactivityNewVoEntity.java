package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api;

import com.inspur.edp.cef.api.attr.I18nResourceAttribute;
import com.inspur.edp.bff.api.manager.IFSManager;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmManager;
import java.util.HashMap;
import com.inspur.edp.cef.api.dataType.base.ICefDataType;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityNewVoBizEntity;
import com.inspur.edp.cef.api.dataType.entity.ICefRootEntity;
public interface IactivityNewVoEntity extends ICefDataType, IactivityNewVoBizEntity, ICefRootEntity {
}

