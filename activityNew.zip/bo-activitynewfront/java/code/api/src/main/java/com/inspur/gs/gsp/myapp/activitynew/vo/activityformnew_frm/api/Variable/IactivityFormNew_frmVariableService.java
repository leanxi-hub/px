package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.Variable;

import java.util.HashMap;
import com.inspur.edp.cef.api.attr.I18nResourceAttribute;
import com.inspur.edp.cef.api.dataType.base.ICefDataType;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.Variable.IactivityFormNew_frmVariableentity;
public interface IactivityFormNew_frmVariableService extends IactivityFormNew_frmVariableVaribaleManager {
}

