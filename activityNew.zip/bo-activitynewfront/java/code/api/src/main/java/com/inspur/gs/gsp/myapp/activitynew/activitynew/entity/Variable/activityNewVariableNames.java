package com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.Variable;

import com.inspur.edp.cef.variable.api.data.IVariableData;
public class activityNewVariableNames {
  public static final String NodeName="activityNewVariable";
}

