package com.inspur.gs.gsp.myapp.activitynew.activitynew.entity;

import com.inspur.edp.cef.entity.entity.IEntityData;
import com.inspur.edp.cef.api.attr.PropertyGetAtrribute;
import java.util.Date;
import com.inspur.edp.cef.api.attr.VersionControlAttribute;
import java.math.BigDecimal;
import com.inspur.edp.cef.api.attr.RootAttribute;
@RootAttribute(objectCode=activityNewNames.NodeName,id="d9dbea89-778b-43ec-a798-ed7004c5d949",keyFieldName="ID") public interface IactivityNew extends IEntityData {
  @PropertyGetAtrribute(propName="ID") String getID();
  void setID(  String value);
  @PropertyGetAtrribute(propName="Version") @VersionControlAttribute() Date getVersion();
  void setVersion(  Date value);
  @PropertyGetAtrribute(propName="Code") String getCode();
  void setCode(  String value);
  @PropertyGetAtrribute(propName="Title") String getTitle();
  void setTitle(  String value);
  @PropertyGetAtrribute(propName="Location") String getLocation();
  void setLocation(  String value);
  @PropertyGetAtrribute(propName="GeoLng") BigDecimal getGeoLng();
  void setGeoLng(  BigDecimal value);
  @PropertyGetAtrribute(propName="GeoLat") BigDecimal getGeoLat();
  void setGeoLat(  BigDecimal value);
  @PropertyGetAtrribute(propName="UpdateInfo") String getUpdateInfo();
  void setUpdateInfo(  String value);
}

