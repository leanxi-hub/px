package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.Variable;

import java.util.HashMap;
import com.inspur.edp.cef.api.attr.I18nResourceAttribute;
import com.inspur.edp.cef.api.dataType.base.ICefDataType;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.Variable.IactivityFormNew_frmVariableentity;
public class activityFormNew_frmVariableDataTypeInfo extends com.inspur.edp.cef.spi.entity.info.AbstractDataTypeInfo {
  @Override public java.lang.String getDisplayValueKey(){
    return ".Name";
  }
  @Override public HashMap<String,Class> getProptyInfoTypes(){
    HashMap<String,Class> dic=new HashMap<String,Class>();
    return dic;
  }
}

