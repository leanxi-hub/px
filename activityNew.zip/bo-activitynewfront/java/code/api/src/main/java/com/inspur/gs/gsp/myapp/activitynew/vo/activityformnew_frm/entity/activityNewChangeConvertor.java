package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity;

import com.inspur.edp.cef.entity.entity.IEntityData;
import com.inspur.edp.cef.api.attr.PropertyGetAtrribute;
import java.util.Date;
import java.math.BigDecimal;
import com.inspur.edp.bff.api.attribute.VMRootAttribute;
import com.inspur.edp.bff.spi.AbstractDataConvertor;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew;
import com.inspur.edp.bff.api.manager.IFSManagerContext;
import java.lang.String;
import java.lang.Object;
import com.inspur.edp.cef.entity.changeset.ModifyChangeDetail;
import com.inspur.edp.bff.spi.AbstractChangeConvertor;
import java.util.HashMap;
import com.inspur.edp.bff.spi.AbstractDefaultValueConvertor;
import com.inspur.edp.bff.api.dataprocessor.IFilterFieldConvertor;
import com.inspur.edp.bff.spi.IHelpMapping;
import com.inspur.edp.bff.spi.utils.ParameterInfo;
import com.inspur.edp.bff.spi.VMHelpConfig;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.inspur.edp.bff.entity.defaultvalue.VoDefaultValue;
import com.fasterxml.jackson.core.JsonParser;
import java.lang.RuntimeException;
import com.inspur.edp.bff.spi.defaultvalue.VoDefaultValueDeserializer;
public class activityNewChangeConvertor extends AbstractChangeConvertor {
  public activityNewChangeConvertor(  IFSManagerContext mgrContext){
    super(mgrContext);
  }
  @Override protected void convertModifyPropFromBE(  String beElementCode,  Object beValue,  ModifyChangeDetail vmChange){
    Object vmValue=null;
switch (beElementCode) {
case "ID":
      vmChange.getPropertyChanges().put("ID",beValue);
    break;
case "Version":
  vmChange.getPropertyChanges().put("Version",beValue);
break;
case "Code":
vmChange.getPropertyChanges().put("Code",beValue);
break;
case "Title":
vmChange.getPropertyChanges().put("Title",beValue);
break;
case "Location":
vmChange.getPropertyChanges().put("Location",beValue);
break;
case "GeoLng":
vmChange.getPropertyChanges().put("GeoLng",beValue);
break;
case "GeoLat":
vmChange.getPropertyChanges().put("GeoLat",beValue);
break;
case "UpdateInfo":
vmChange.getPropertyChanges().put("UpdateInfo",beValue);
break;
}
}
@Override protected void convertModifyPropFromVM(String vmElementCode,Object vmValue,ModifyChangeDetail beChange){
Object beValue=null;
switch (vmElementCode) {
case "ID":
beChange.getPropertyChanges().put("ID",vmValue);
break;
case "Version":
beChange.getPropertyChanges().put("Version",vmValue);
break;
case "Code":
beChange.getPropertyChanges().put("Code",vmValue);
break;
case "Title":
beChange.getPropertyChanges().put("Title",vmValue);
break;
case "Location":
beChange.getPropertyChanges().put("Location",vmValue);
break;
case "GeoLng":
beChange.getPropertyChanges().put("GeoLng",vmValue);
break;
case "GeoLat":
beChange.getPropertyChanges().put("GeoLat",vmValue);
break;
case "UpdateInfo":
beChange.getPropertyChanges().put("UpdateInfo",vmValue);
break;
}
}
@Override protected void convertMultiLanguageModifyPropFromBE(String beElementCode,Object beValue,ModifyChangeDetail vmChange){
Object vmValue=null;
switch (beElementCode) {
}
}
@Override protected void convertMultiLanguageModifyPropFromVo(String vmElementCode,Object vmValue,ModifyChangeDetail beChange){
Object beValue=null;
switch (vmElementCode) {
}
}
@Override protected AbstractChangeConvertor getChildChangeConvertor(String childCode){
return null;
}
}

