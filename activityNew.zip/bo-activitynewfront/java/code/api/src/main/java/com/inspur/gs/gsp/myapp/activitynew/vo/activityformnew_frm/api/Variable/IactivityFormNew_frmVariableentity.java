package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.Variable;

import java.util.HashMap;
import com.inspur.edp.cef.api.attr.I18nResourceAttribute;
import com.inspur.edp.cef.api.dataType.base.ICefDataType;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.Variable.IactivityFormNew_frmVariableentity;
@I18nResourceAttribute(resourceInfoType=activityFormNew_frmVariableDataTypeInfo.class) public interface IactivityFormNew_frmVariableentity {
}

