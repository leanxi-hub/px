package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api;

import com.inspur.edp.cef.api.attr.I18nResourceAttribute;
import com.inspur.edp.bff.api.manager.IFSManager;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmManager;
import java.util.HashMap;
import com.inspur.edp.cef.api.dataType.base.ICefDataType;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityNewVoBizEntity;
import com.inspur.edp.cef.api.dataType.entity.ICefRootEntity;
public class activityNewLocationPropInfo extends com.inspur.edp.bff.spi.i18n.VoPropInfo {
  @Override public java.lang.String getName(){
    return "Location";
  }
  @Override public boolean getRequired(){
    return false;
  }
  @Override public int getPrecision(){
    return 0;
  }
  @Override public int getLength(){
    return 1024;
  }
  @Override public java.lang.String getDisplayValueKey(){
    return "Inspur.GS.Gsp.myapp.activityNew.Vo.activityFormNew_frm.activityNew.Location.Name";
  }
  @Override public com.inspur.edp.cef.entity.entity.FieldType getType(){
    return com.inspur.edp.cef.entity.entity.FieldType.String;
  }
}

