package com.inspur.gs.gsp.myapp.activitynew.activitynew.api;

import com.inspur.edp.cef.api.attr.I18nResourceAttribute;
import com.inspur.edp.bef.api.be.IBEService;
import java.util.HashMap;
import com.inspur.edp.cef.api.dataType.base.ICefDataType;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewBizEntity;
import com.inspur.edp.bef.api.be.IBusinessEntity;
import com.inspur.edp.bef.api.action.assembler.IMgrActionAssemblerFactory;
import com.inspur.edp.bef.api.attr.AssemblerMethodAttribute;
import com.inspur.edp.bef.spi.action.assembler.query.QueryMgrActionAssembler;
import com.inspur.edp.bef.api.be.IBEManagerContext;
import com.inspur.edp.cef.entity.condition.EntityFilter;
import com.inspur.edp.bef.spi.action.assembler.retrieveDefault.RetrieveDefaultMgrActionAssembler;
import com.inspur.edp.bef.spi.action.assembler.retrieve.RetrieveMgrActionAssembler;
import com.inspur.edp.bef.api.parameter.retrieve.RetrieveParam;
import com.inspur.edp.bef.spi.action.assembler.modify.ModifyMgrActionAssembler;
import com.inspur.edp.cef.entity.changeset.IChangeDetail;
import com.inspur.edp.bef.spi.action.assembler.delete.DeleteMgrActionAssembler;
import com.inspur.edp.bef.api.action.assembler.IAbstractActionAssemblerFactory;
import com.inspur.edp.bef.api.be.IBEContext;
public class activityNewEntityInfo extends com.inspur.edp.bef.spi.entity.info.BeEntityInfo {
  @Override public java.lang.String getDisplayValueKey(){
    return "Inspur.GS.Gsp.myapp.activityNew.activityNew.activityNew.Name";
  }
  @Override public HashMap<String,Class> getProptyInfoTypes(){
    HashMap<String,Class> dic=new HashMap<String,Class>();
    dic.put("GeoLat",activityNewGeoLatPropInfo.class);
    dic.put("Version",activityNewVersionPropInfo.class);
    dic.put("Title",activityNewTitlePropInfo.class);
    dic.put("ID",activityNewIDPropInfo.class);
    dic.put("Code",activityNewCodePropInfo.class);
    dic.put("GeoLng",activityNewGeoLngPropInfo.class);
    dic.put("UpdateInfo",activityNewUpdateInfoPropInfo.class);
    dic.put("Location",activityNewLocationPropInfo.class);
    return dic;
  }
  @Override public HashMap<String,Class> getUniqueConstraintInfoTypes(){
    HashMap<String,Class> dic=new HashMap<String,Class>();
    return dic;
  }
}

