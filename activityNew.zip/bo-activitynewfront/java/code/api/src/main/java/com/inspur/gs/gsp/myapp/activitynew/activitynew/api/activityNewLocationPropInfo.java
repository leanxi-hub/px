package com.inspur.gs.gsp.myapp.activitynew.activitynew.api;

import com.inspur.edp.cef.api.attr.I18nResourceAttribute;
import com.inspur.edp.bef.api.be.IBEService;
import java.util.HashMap;
import com.inspur.edp.cef.api.dataType.base.ICefDataType;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewBizEntity;
import com.inspur.edp.bef.api.be.IBusinessEntity;
import com.inspur.edp.bef.api.action.assembler.IMgrActionAssemblerFactory;
import com.inspur.edp.bef.api.attr.AssemblerMethodAttribute;
import com.inspur.edp.bef.spi.action.assembler.query.QueryMgrActionAssembler;
import com.inspur.edp.bef.api.be.IBEManagerContext;
import com.inspur.edp.cef.entity.condition.EntityFilter;
import com.inspur.edp.bef.spi.action.assembler.retrieveDefault.RetrieveDefaultMgrActionAssembler;
import com.inspur.edp.bef.spi.action.assembler.retrieve.RetrieveMgrActionAssembler;
import com.inspur.edp.bef.api.parameter.retrieve.RetrieveParam;
import com.inspur.edp.bef.spi.action.assembler.modify.ModifyMgrActionAssembler;
import com.inspur.edp.cef.entity.changeset.IChangeDetail;
import com.inspur.edp.bef.spi.action.assembler.delete.DeleteMgrActionAssembler;
import com.inspur.edp.bef.api.action.assembler.IAbstractActionAssemblerFactory;
import com.inspur.edp.bef.api.be.IBEContext;
public class activityNewLocationPropInfo extends com.inspur.edp.bef.spi.entity.info.BePropInfo {
  @Override public java.lang.String getName(){
    return "Location";
  }
  @Override public boolean getRequired(){
    return false;
  }
  @Override public int getPrecision(){
    return 0;
  }
  @Override public int getLength(){
    return 1024;
  }
  @Override public java.lang.String getDisplayValueKey(){
    return "Inspur.GS.Gsp.myapp.activityNew.activityNew.activityNew.Location.Name";
  }
  @Override public com.inspur.edp.cef.entity.entity.FieldType getType(){
    return com.inspur.edp.cef.entity.entity.FieldType.String;
  }
  @Override public boolean getIsDefaultNull(){
    return false;
  }
}

