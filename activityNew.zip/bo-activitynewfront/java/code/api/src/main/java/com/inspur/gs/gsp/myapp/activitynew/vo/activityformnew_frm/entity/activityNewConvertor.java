package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity;

import com.inspur.edp.cef.entity.entity.IEntityData;
import com.inspur.edp.cef.api.attr.PropertyGetAtrribute;
import java.util.Date;
import java.math.BigDecimal;
import com.inspur.edp.bff.api.attribute.VMRootAttribute;
import com.inspur.edp.bff.spi.AbstractDataConvertor;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew;
import com.inspur.edp.bff.api.manager.IFSManagerContext;
import java.lang.String;
import java.lang.Object;
import com.inspur.edp.cef.entity.changeset.ModifyChangeDetail;
import com.inspur.edp.bff.spi.AbstractChangeConvertor;
import java.util.HashMap;
import com.inspur.edp.bff.spi.AbstractDefaultValueConvertor;
import com.inspur.edp.bff.api.dataprocessor.IFilterFieldConvertor;
import com.inspur.edp.bff.spi.IHelpMapping;
import com.inspur.edp.bff.spi.utils.ParameterInfo;
import com.inspur.edp.bff.spi.VMHelpConfig;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.inspur.edp.bff.entity.defaultvalue.VoDefaultValue;
import com.fasterxml.jackson.core.JsonParser;
import java.lang.RuntimeException;
import com.inspur.edp.bff.spi.defaultvalue.VoDefaultValueDeserializer;
public class activityNewConvertor extends AbstractDataConvertor {
  public activityNewConvertor(){
  }
  @Override public AbstractDataConvertor getChildDataConvertor(  String childCode){
    return null;
  }
  @Override protected void mappingEntityDataProperties(  IEntityData beData,  IEntityData vmData){
    IactivityNew _beData=(IactivityNew)beData;
    IactivityNewView _vmData=(IactivityNewView)vmData;
    _vmData.setID(_beData.getID());
    _vmData.setVersion(_beData.getVersion());
    _vmData.setCode(_beData.getCode());
    _vmData.setTitle(_beData.getTitle());
    _vmData.setLocation(_beData.getLocation());
    _vmData.setGeoLng(_beData.getGeoLng());
    _vmData.setGeoLat(_beData.getGeoLat());
    _vmData.setUpdateInfo(_beData.getUpdateInfo());
  }
  @Override protected void mappingEntityDataPropertiesFromVo(  IEntityData beData,  IEntityData vmData){
    IactivityNew _beData=(IactivityNew)beData;
    IactivityNewView _vmData=(IactivityNewView)vmData;
    _beData.setID(_vmData.getID());
    _beData.setVersion(_vmData.getVersion());
    _beData.setCode(_vmData.getCode());
    _beData.setTitle(_vmData.getTitle());
    _beData.setLocation(_vmData.getLocation());
    _beData.setGeoLng(_vmData.getGeoLng());
    _beData.setGeoLat(_vmData.getGeoLat());
    _beData.setUpdateInfo(_vmData.getUpdateInfo());
  }
  @Override protected boolean checkChildCode(  String childCode){
    return false;
  }
  @Override protected void mappingEntityDataMultiLanguagePropsFromVo(  IEntityData beData,  IEntityData vmData){
    com.inspur.edp.cef.entity.entity.IMultiLanguageData _beMultiLanguageData=(com.inspur.edp.cef.entity.entity.IMultiLanguageData)beData;
    com.inspur.edp.cef.entity.entity.IMultiLanguageData vmMultiLanguageData=(com.inspur.edp.cef.entity.entity.IMultiLanguageData)vmData;
  }
  @Override protected void mappingEntityDataMultiLanguageProps(  IEntityData beData,  IEntityData vmData){
    com.inspur.edp.cef.entity.entity.IMultiLanguageData _beMultiLanguageData=(com.inspur.edp.cef.entity.entity.IMultiLanguageData)beData;
    com.inspur.edp.cef.entity.entity.IMultiLanguageData _vmMultiLanguageData=(com.inspur.edp.cef.entity.entity.IMultiLanguageData)vmData;
  }
}

