package com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.Variable;

import com.inspur.edp.cef.variable.api.data.IVariableData;
public interface IactivityNewVariable extends IVariableData {
}

