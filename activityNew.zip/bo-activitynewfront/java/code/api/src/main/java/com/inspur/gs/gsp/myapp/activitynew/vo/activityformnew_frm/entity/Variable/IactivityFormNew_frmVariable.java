package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.Variable;

import com.inspur.edp.cef.variable.api.data.IVariableData;
public interface IactivityFormNew_frmVariable extends IVariableData {
}

