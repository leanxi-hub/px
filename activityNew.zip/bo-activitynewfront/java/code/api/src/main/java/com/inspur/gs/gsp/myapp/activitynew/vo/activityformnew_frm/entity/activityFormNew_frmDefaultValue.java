package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity;

import com.inspur.edp.cef.entity.entity.IEntityData;
import com.inspur.edp.cef.api.attr.PropertyGetAtrribute;
import java.util.Date;
import java.math.BigDecimal;
import com.inspur.edp.bff.api.attribute.VMRootAttribute;
import com.inspur.edp.bff.spi.AbstractDataConvertor;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew;
import com.inspur.edp.bff.api.manager.IFSManagerContext;
import java.lang.String;
import java.lang.Object;
import com.inspur.edp.cef.entity.changeset.ModifyChangeDetail;
import com.inspur.edp.bff.spi.AbstractChangeConvertor;
import java.util.HashMap;
import com.inspur.edp.bff.spi.AbstractDefaultValueConvertor;
import com.inspur.edp.bff.api.dataprocessor.IFilterFieldConvertor;
import com.inspur.edp.bff.spi.IHelpMapping;
import com.inspur.edp.bff.spi.utils.ParameterInfo;
import com.inspur.edp.bff.spi.VMHelpConfig;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.inspur.edp.bff.entity.defaultvalue.VoDefaultValue;
import com.fasterxml.jackson.core.JsonParser;
import java.lang.RuntimeException;
import com.inspur.edp.bff.spi.defaultvalue.VoDefaultValueDeserializer;
@JsonDeserialize(using=activityFormNew_frmDefaultValueConvertor.class) public class activityFormNew_frmDefaultValue extends VoDefaultValue {
}

