package com.inspur.gs.gsp.myapp.activitynew.activitynew.api.Variable;

import java.util.HashMap;
import com.inspur.edp.cef.api.attr.I18nResourceAttribute;
import com.inspur.edp.cef.api.dataType.base.ICefDataType;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.Variable.IactivityNewVariableentity;
public class activityNewVariableDataTypeInfo extends com.inspur.edp.cef.spi.entity.info.AbstractDataTypeInfo {
  @Override public java.lang.String getDisplayValueKey(){
    return ".Name";
  }
  @Override public HashMap<String,Class> getProptyInfoTypes(){
    HashMap<String,Class> dic=new HashMap<String,Class>();
    return dic;
  }
}

