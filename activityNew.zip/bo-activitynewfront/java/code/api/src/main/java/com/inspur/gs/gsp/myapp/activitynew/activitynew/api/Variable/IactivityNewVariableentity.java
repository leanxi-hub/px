package com.inspur.gs.gsp.myapp.activitynew.activitynew.api.Variable;

import java.util.HashMap;
import com.inspur.edp.cef.api.attr.I18nResourceAttribute;
import com.inspur.edp.cef.api.dataType.base.ICefDataType;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.Variable.IactivityNewVariableentity;
@I18nResourceAttribute(resourceInfoType=activityNewVariableDataTypeInfo.class) public interface IactivityNewVariableentity {
}

