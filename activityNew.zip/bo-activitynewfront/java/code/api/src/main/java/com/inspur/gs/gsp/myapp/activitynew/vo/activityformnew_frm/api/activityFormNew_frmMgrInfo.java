package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api;

import com.inspur.edp.cef.api.attr.I18nResourceAttribute;
import com.inspur.edp.bff.api.manager.IFSManager;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmManager;
import java.util.HashMap;
import com.inspur.edp.cef.api.dataType.base.ICefDataType;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityNewVoBizEntity;
import com.inspur.edp.cef.api.dataType.entity.ICefRootEntity;
public class activityFormNew_frmMgrInfo extends com.inspur.edp.bff.spi.i18n.ViewModelMgrInfo {
  @Override public java.lang.String getDisplayValueKey(){
    return "Inspur.GS.Gsp.myapp.activityNew.Vo.activityFormNew_frm.Name";
  }
  @Override public java.lang.String getResourceMetaId(){
    return "3c8223ca-6136-400e-8a1e-35612a0201b1";
  }
  @Override public java.lang.String getRootNodeCode(){
    return "activityNew";
  }
  @Override public java.lang.String getCurrentSU(){
    return "myapp";
  }
}

