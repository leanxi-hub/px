package com.inspur.gs.gsp.myapp.activitynew.activitynew.entity;

import com.inspur.edp.cef.entity.entity.IEntityData;
import com.inspur.edp.cef.api.attr.PropertyGetAtrribute;
import java.util.Date;
import com.inspur.edp.cef.api.attr.VersionControlAttribute;
import java.math.BigDecimal;
import com.inspur.edp.cef.api.attr.RootAttribute;
public class activityNewNames {
  public static final String NodeName="activityNew";
  public static final String ID="ID";
  public static final String Version="Version";
  public static final String Code="Code";
  public static final String Title="Title";
  public static final String Location="Location";
  public static final String GeoLng="GeoLng";
  public static final String GeoLat="GeoLat";
  public static final String UpdateInfo="UpdateInfo";
}

