package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api;

import com.inspur.edp.cef.api.attr.I18nResourceAttribute;
import com.inspur.edp.bff.api.manager.IFSManager;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmManager;
import java.util.HashMap;
import com.inspur.edp.cef.api.dataType.base.ICefDataType;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityNewVoBizEntity;
import com.inspur.edp.cef.api.dataType.entity.ICefRootEntity;
public class activityNewEntityInfo extends com.inspur.edp.bff.spi.i18n.VoEntityInfo {
  @Override public java.lang.String getDisplayValueKey(){
    return "Inspur.GS.Gsp.myapp.activityNew.Vo.activityFormNew_frm.activityNew.Name";
  }
  @Override public HashMap<String,Class> getProptyInfoTypes(){
    HashMap<String,Class> dic=new HashMap<String,Class>();
    dic.put("GeoLat",activityNewGeoLatPropInfo.class);
    dic.put("Version",activityNewVersionPropInfo.class);
    dic.put("Title",activityNewTitlePropInfo.class);
    dic.put("ID",activityNewIDPropInfo.class);
    dic.put("Code",activityNewCodePropInfo.class);
    dic.put("GeoLng",activityNewGeoLngPropInfo.class);
    dic.put("UpdateInfo",activityNewUpdateInfoPropInfo.class);
    dic.put("Location",activityNewLocationPropInfo.class);
    return dic;
  }
  @Override public HashMap<String,Class> getUniqueConstraintInfoTypes(){
    HashMap<String,Class> dic=new HashMap<String,Class>();
    return dic;
  }
}

