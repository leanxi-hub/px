package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frmgen;

import com.inspur.edp.cef.spi.determination.IDetermination;
import com.inspur.edp.cef.spi.validation.IValidation;
import com.inspur.edp.cef.entity.changeset.ModifyChangeDetail;
import com.inspur.edp.cef.entity.changeset.ValueObjModifyChangeDetail;
import com.inspur.edp.cef.entity.changeset.DeleteChangeDetail;
import com.inspur.edp.cef.entity.changeset.AddChangeDetail;
import com.inspur.edp.cef.entity.changeset.IChangeDetail;
import java.util.Map;
import com.inspur.edp.cef.entity.accessor.base.IAccessor;
import com.inspur.edp.cef.entity.accessor.base.ReadonlyDataException;
import java.util.HashMap;
import com.inspur.edp.bff.spi.action.query.BeforeQueryAction;
import com.inspur.edp.bff.spi.action.query.AbstractQueryAction;
import com.inspur.edp.bff.spi.action.query.AfterQueryAction;
import com.inspur.edp.bff.spi.action.datamapping.DataMappingAction;
import com.inspur.edp.bff.spi.action.datamapping.DataReversalMappingAction;
import com.inspur.edp.bff.spi.action.retrieve.BeforeRetrieveAction;
import com.inspur.edp.bff.spi.action.retrieve.AbstractRetrieveAction;
import com.inspur.edp.bff.spi.action.retrieve.AfterRetrieveAction;
import com.inspur.edp.bff.spi.action.retrievedefault.BeforeRetrieveDefaultAction;
import com.inspur.edp.bff.spi.action.retrievedefault.AbstractRetrieveDefaultAction;
import com.inspur.edp.bff.spi.action.retrievedefault.AfterRetrieveDefaultAction;
import com.inspur.edp.bff.spi.action.delete.BeforeDeleteAction;
import com.inspur.edp.bff.spi.action.delete.AbstractDeleteAction;
import com.inspur.edp.bff.spi.action.delete.AfterDeleteAction;
import com.inspur.edp.bff.spi.action.multidelete.BeforeMultiDeleteAction;
import com.inspur.edp.bff.spi.action.multidelete.AbstractMultiDeleteAction;
import com.inspur.edp.bff.spi.action.multidelete.AfterMultiDeleteAction;
import com.inspur.edp.bff.spi.action.modify.BeforeModifyAction;
import com.inspur.edp.bff.spi.action.modify.AbstractModifyAction;
import com.inspur.edp.bff.spi.action.modify.AfterModifyAction;
import com.inspur.edp.bff.spi.action.save.BeforeSaveAction;
import com.inspur.edp.bff.spi.action.save.AfterSaveAction;
import java.lang.Cloneable;
import com.inspur.edp.cef.entity.entity.EntityDataCollection;
import java.lang.String;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeDeseiralizer;
import com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeSerializer;
import java.util.Date;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import java.math.BigDecimal;
import java.lang.Object;
import com.inspur.edp.cef.entity.entity.ICefData;
import com.inspur.edp.cef.entity.accessor.base.AccessorBase;
import com.inspur.edp.cef.entity.entity.IEntityDataCollection;
import java.lang.Override;
import com.inspur.edp.cef.api.dataType.entity.ICefEntity;
import com.inspur.edp.bff.core.entity.ViewObjectEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.IactivityNewView;
import com.inspur.edp.commonmodel.spi.AbstractEntityDataSerializer;
import com.inspur.edp.bff.spi.AbstractBffEntitySerConvertor;
import com.inspur.edp.commonmodel.spi.AbstractEntityDataDeSerializer;
import com.inspur.edp.bff.spi.AbstractBffEntityDeserConvertor;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.bff.spi.changeset.AbstractBffChangeJsonSerializer;
import com.inspur.edp.bff.spi.changeset.AbstractBffChangeJsonDeserializer;
import com.inspur.edp.cef.core.i18n.I18nResourceUtil;
import com.inspur.edp.cef.spi.entity.info.EnumValueInfo;
import com.inspur.edp.cef.spi.entity.resourceInfo.EntityResInfo;
import com.inspur.edp.cef.spi.entity.resourceInfo.ModelResInfo;
import com.inspur.edp.cef.api.request.RequestInfo;
import com.inspur.edp.bff.api.manager.IFSManager;
import com.inspur.edp.bff.spi.request.RequestConvertor;
import com.inspur.edp.cef.api.response.ResponseInfo;
import com.inspur.edp.bff.spi.response.ResponseConvertor;
import com.inspur.edp.bff.api.attribute.AbstractSourceConfig;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityFormNew_frmSourceConfig;
import com.inspur.edp.cef.entity.entity.IEntityData;
import com.inspur.edp.bff.api.dataprocessor.IChangeConvertor;
import com.inspur.edp.bff.api.dataprocessor.IDataConvertor;
import com.inspur.edp.bff.api.dataprocessor.IDefaultValueConvertor;
import java.lang.Class;
import java.lang.RuntimeException;
import com.inspur.edp.bff.spi.VMHelpConfig;
import java.util.ArrayList;
import com.inspur.edp.bff.spi.IHelpExtend;
import com.inspur.edp.bff.api.manager.assembler.IAssemblerManager;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frmgenvariable.activityFormNew_frmvariableManager;
import com.inspur.edp.cef.variable.api.manager.IVariableManager;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewFilterConvertor;
import com.inspur.edp.bff.api.dataprocessor.IFilterFieldConvertor;
import com.inspur.edp.cef.api.dataType.entity.ICefRootEntity;
import com.inspur.edp.bff.api.manager.context.QueryContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendQueryAssembler;
import com.inspur.edp.bff.api.manager.context.DataMapperContext;
import com.inspur.edp.bff.spi.assembler.AbstractDataMapperAssembler;
import com.inspur.edp.bff.api.manager.context.RetrieveContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendRetrieveAssembler;
import com.inspur.edp.bff.api.manager.context.RetrieveDefaultContext;
import com.inspur.edp.bff.spi.assembler.AbstractRetrieveDefaultAssembler;
import com.inspur.edp.bff.api.manager.context.ModifyContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendModifyAssembler;
import com.inspur.edp.bff.api.manager.context.DeleteContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendDeleteAssembler;
import com.inspur.edp.bff.api.manager.context.SaveContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendSaveAssembler;
import com.inspur.edp.bff.spi.action.changemapping.ChangeMappingAction;
import com.inspur.edp.bff.api.manager.context.ChangeMapperContext;
import com.inspur.edp.bff.spi.action.changemapping.ChangeReversalMappingAction;
import com.inspur.edp.bff.spi.assembler.AbstractChangeMapperAssembler;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmService;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmManager;
import com.inspur.edp.bff.api.manager.assembler.IExtendQueryAssembler;
import com.inspur.edp.bff.api.manager.assembler.IDataMapperAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendRetrieveAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendRetrieveDefaultAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendDeleteAssembler;
import com.inspur.edp.bff.api.manager.assembler.IChangeMapperAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendModifyAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendSaveAssembler;
import com.inspur.edp.bff.entity.changeset.ViewModelChangeset;
import com.inspur.edp.bff.spi.changeset.AbstractVMChangeConvertor;
@JsonSerialize(using=EntitySerConvertor.class) @JsonDeserialize(using=EntityDeserConvertor.class) public class activityFormNew_frmData extends com.inspur.edp.cef.core.data.EntityDataBase implements Cloneable, com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.IactivityNewView {
  public activityFormNew_frmData(){
  }
  @JsonProperty("location") @Override public String getLocation(){
    return locationfield;
  }
  @Override public void setLocation(  String value){
    locationfield=value;
  }
  @JsonProperty("id") @Override public String getID(){
    return idfield;
  }
  @Override public void setID(  String value){
    idfield=value;
  }
  @JsonProperty("version") @JsonDeserialize(using=com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeDeseiralizer.class) @Override public Date getVersion(){
    return versionfield;
  }
  @JsonSerialize(using=com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeSerializer.class) @Override public void setVersion(  Date value){
    versionfield=value;
  }
  @JsonProperty("code") @Override public String getCode(){
    return codefield;
  }
  @Override public void setCode(  String value){
    codefield=value;
  }
  @JsonProperty("title") @Override public String getTitle(){
    return titlefield;
  }
  @Override public void setTitle(  String value){
    titlefield=value;
  }
  @JsonProperty("updateInfo") @Override public String getUpdateInfo(){
    return updateinfofield;
  }
  @Override public void setUpdateInfo(  String value){
    updateinfofield=value;
  }
  @JsonProperty("geoLng") @Override public BigDecimal getGeoLng(){
    return geolngfield;
  }
  @Override public void setGeoLng(  BigDecimal value){
    geolngfield=value;
  }
  @JsonProperty("geoLat") @Override public BigDecimal getGeoLat(){
    return geolatfield;
  }
  @Override public void setGeoLat(  BigDecimal value){
    geolatfield=value;
  }
  @Override public boolean equals(  Object obj){
    if (obj == null)     return false;
    com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.IactivityNewView newObj=(com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.IactivityNewView)obj;
    if (this.getLocation() == null) {
      if (newObj.getLocation() != null)       return false;
    }
 else     if (this.getLocation().equals(newObj.getLocation()) == false)     return false;
    if (this.getID() == null) {
      if (newObj.getID() != null)       return false;
    }
 else     if (this.getID().equals(newObj.getID()) == false)     return false;
    if (this.getVersion() == null) {
      if (newObj.getVersion() != null)       return false;
    }
 else     if (this.getVersion().equals(newObj.getVersion()) == false)     return false;
    if (this.getCode() == null) {
      if (newObj.getCode() != null)       return false;
    }
 else     if (this.getCode().equals(newObj.getCode()) == false)     return false;
    if (this.getTitle() == null) {
      if (newObj.getTitle() != null)       return false;
    }
 else     if (this.getTitle().equals(newObj.getTitle()) == false)     return false;
    if (this.getUpdateInfo() == null) {
      if (newObj.getUpdateInfo() != null)       return false;
    }
 else     if (this.getUpdateInfo().equals(newObj.getUpdateInfo()) == false)     return false;
    if (this.getGeoLng() == null) {
      if (newObj.getGeoLng() != null)       return false;
    }
 else     if (this.getGeoLng().equals(newObj.getGeoLng()) == false)     return false;
    if (this.getGeoLat() == null) {
      if (newObj.getGeoLat() != null)       return false;
    }
 else     if (this.getGeoLat().equals(newObj.getGeoLat()) == false)     return false;
    return true;
  }
  protected com.inspur.edp.cef.entity.entity.ICefData innerCopy(){
    try {
      activityFormNew_frmData result=(activityFormNew_frmData)this.clone();
      result.setLocation(this.getLocation());
      result.setID(this.getID());
      result.setVersion(this.getVersion());
      result.setCode(this.getCode());
      result.setTitle(this.getTitle());
      result.setUpdateInfo(this.getUpdateInfo());
      result.setGeoLng(this.getGeoLng());
      result.setGeoLat(this.getGeoLat());
      return result;
    }
 catch (    CloneNotSupportedException e) {
      throw new RuntimeException();
    }
  }
  @Override protected com.inspur.edp.cef.entity.entity.ICefData innerCopySelf(){
    try {
      return (ICefData)clone();
    }
 catch (    CloneNotSupportedException e) {
      throw new RuntimeException();
    }
  }
  @Override protected java.lang.Object innerGetValue(  java.lang.String propName){
switch (propName) {
case "Location":
      return getLocation();
case "ID":
    return getID();
case "Version":
  return getVersion();
case "Code":
return getCode();
case "Title":
return getTitle();
case "UpdateInfo":
return getUpdateInfo();
case "GeoLng":
return getGeoLng();
case "GeoLat":
return getGeoLat();
default :
throw new RuntimeException("属性名不存在：" + propName);
}
}
@Override protected void innerSetValue(java.lang.String propName,java.lang.Object value){
switch (propName) {
case "Location":
setLocation((String)value);
break;
case "ID":
setID((String)value);
break;
case "Version":
setVersion((Date)value);
break;
case "Code":
setCode((String)value);
break;
case "Title":
setTitle((String)value);
break;
case "UpdateInfo":
setUpdateInfo((String)value);
break;
case "GeoLng":
setGeoLng((BigDecimal)value);
break;
case "GeoLat":
setGeoLat((BigDecimal)value);
break;
default :
throw new RuntimeException("属性名不存在：" + propName);
}
}
@Override protected java.util.ArrayList<java.lang.String> innerGetPropertyNames(){
ArrayList<String> list=new ArrayList();
list.add("Location");
list.add("ID");
list.add("Version");
list.add("Code");
list.add("Title");
list.add("UpdateInfo");
list.add("GeoLng");
list.add("GeoLat");
return list;
}
@Override protected com.inspur.edp.cef.entity.entity.ICefData innerCreateChild(java.lang.String childCode){
throw new RuntimeException("不存在子表" + childCode);
}
@Override protected java.util.HashMap<String,IEntityDataCollection> innerGetChilds(){
HashMap<String,IEntityDataCollection> childs=new HashMap<>();
return childs;
}
@Override protected void innerMergeChildData(java.lang.String nodeCode,java.util.ArrayList<com.inspur.edp.cef.entity.entity.IEntityData> childData){
throw new RuntimeException("不存在子表" + nodeCode);
}
private java.lang.String locationfield;
private java.lang.String idfield;
private java.util.Date versionfield;
private java.lang.String codefield;
private java.lang.String titlefield;
private java.lang.String updateinfofield;
private java.math.BigDecimal geolngfield;
private java.math.BigDecimal geolatfield;
}

