package com.inspur.gs.gsp.myapp.activitynew.activitynewgenvariable;

import com.inspur.edp.cef.spi.determination.IDetermination;
import com.inspur.edp.cef.entity.accessor.base.ReadonlyDataException;
import java.util.HashMap;
import com.inspur.edp.bef.api.be.BEInfo;
import com.inspur.edp.cef.variable.api.variable.IVariable;
import com.inspur.edp.cef.entity.entity.IValueObjData;
import java.lang.Cloneable;
import com.inspur.edp.cef.entity.entity.EntityDataCollection;
import java.lang.Object;
import com.inspur.edp.cef.entity.accessor.base.AccessorBase;
import com.inspur.edp.cef.entity.changeset.ValueObjModifyChangeDetail;
import com.inspur.edp.cef.entity.entity.ICefData;
import java.util.List;
import com.inspur.edp.cef.api.dataType.valueObj.ICefValueObjContext;
import java.util.ArrayList;
import com.inspur.edp.cef.variable.api.variable.IVariableContext;
import com.inspur.edp.cef.variable.core.variable.AbstractVariable;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.cef.spi.jsonser.valueobj.AbstractValueObjSerializer;
public class activityNewVariableAcc extends com.inspur.edp.cef.core.data.ValueObjAccessor implements com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.Variable.IactivityNewVariable {
  public activityNewVariableAcc(  com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.Variable.IactivityNewVariable data){
    super(data);
    Initialize();
  }
  @Override public com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.Variable.IactivityNewVariable getInnerData(){
    return (com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.Variable.IactivityNewVariable)super.getInnerData();
  }
  @Override public boolean equals(  Object obj){
    if (obj == null)     return false;
    com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.Variable.IactivityNewVariable newObj=(com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.Variable.IactivityNewVariable)obj;
    return true;
  }
  @Override protected java.lang.Object innerGetValue(  java.lang.String propName){
switch (propName) {
default :
      throw new RuntimeException("属性名不存在：" + propName);
  }
}
@Override public boolean getIsReadonly(){
  return false;
}
@Override protected void innerSetValue(java.lang.String propName,java.lang.Object value){
switch (propName) {
default :
    throw new RuntimeException("属性名不存在：" + propName);
}
}
private void Initialize(){
initializeNested();
}
@Override public void copyCore(com.inspur.edp.cef.entity.accessor.base.AccessorBase accessor){
activityNewVariableAcc result=(activityNewVariableAcc)accessor;
}
@Override protected AccessorBase createNewObject(){
return new activityNewVariableAcc(null);
}
@Override protected void acceptChangeCore(com.inspur.edp.cef.entity.changeset.IChangeDetail change){
super.acceptChangeCore(change);
ValueObjModifyChangeDetail var=change instanceof ValueObjModifyChangeDetail ? (ValueObjModifyChangeDetail)change : null;
if (var == null) {
  throw new RuntimeException();
}
for (java.util.Map.Entry<String,Object> propertyChange : var.getPropertyChanges().entrySet()) {
switch (propertyChange.getKey()) {
  }
}
}
public void initializeNested(){
}
}

