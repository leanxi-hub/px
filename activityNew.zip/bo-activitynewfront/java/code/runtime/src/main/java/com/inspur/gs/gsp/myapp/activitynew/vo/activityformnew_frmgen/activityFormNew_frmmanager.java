package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frmgen;

import com.inspur.edp.cef.spi.determination.IDetermination;
import com.inspur.edp.cef.spi.validation.IValidation;
import com.inspur.edp.cef.entity.changeset.ModifyChangeDetail;
import com.inspur.edp.cef.entity.changeset.ValueObjModifyChangeDetail;
import com.inspur.edp.cef.entity.changeset.DeleteChangeDetail;
import com.inspur.edp.cef.entity.changeset.AddChangeDetail;
import com.inspur.edp.cef.entity.changeset.IChangeDetail;
import java.util.Map;
import com.inspur.edp.cef.entity.accessor.base.IAccessor;
import com.inspur.edp.cef.entity.accessor.base.ReadonlyDataException;
import java.util.HashMap;
import com.inspur.edp.bff.spi.action.query.BeforeQueryAction;
import com.inspur.edp.bff.spi.action.query.AbstractQueryAction;
import com.inspur.edp.bff.spi.action.query.AfterQueryAction;
import com.inspur.edp.bff.spi.action.datamapping.DataMappingAction;
import com.inspur.edp.bff.spi.action.datamapping.DataReversalMappingAction;
import com.inspur.edp.bff.spi.action.retrieve.BeforeRetrieveAction;
import com.inspur.edp.bff.spi.action.retrieve.AbstractRetrieveAction;
import com.inspur.edp.bff.spi.action.retrieve.AfterRetrieveAction;
import com.inspur.edp.bff.spi.action.retrievedefault.BeforeRetrieveDefaultAction;
import com.inspur.edp.bff.spi.action.retrievedefault.AbstractRetrieveDefaultAction;
import com.inspur.edp.bff.spi.action.retrievedefault.AfterRetrieveDefaultAction;
import com.inspur.edp.bff.spi.action.delete.BeforeDeleteAction;
import com.inspur.edp.bff.spi.action.delete.AbstractDeleteAction;
import com.inspur.edp.bff.spi.action.delete.AfterDeleteAction;
import com.inspur.edp.bff.spi.action.multidelete.BeforeMultiDeleteAction;
import com.inspur.edp.bff.spi.action.multidelete.AbstractMultiDeleteAction;
import com.inspur.edp.bff.spi.action.multidelete.AfterMultiDeleteAction;
import com.inspur.edp.bff.spi.action.modify.BeforeModifyAction;
import com.inspur.edp.bff.spi.action.modify.AbstractModifyAction;
import com.inspur.edp.bff.spi.action.modify.AfterModifyAction;
import com.inspur.edp.bff.spi.action.save.BeforeSaveAction;
import com.inspur.edp.bff.spi.action.save.AfterSaveAction;
import java.lang.Cloneable;
import com.inspur.edp.cef.entity.entity.EntityDataCollection;
import java.lang.String;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeDeseiralizer;
import com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeSerializer;
import java.util.Date;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import java.math.BigDecimal;
import java.lang.Object;
import com.inspur.edp.cef.entity.entity.ICefData;
import com.inspur.edp.cef.entity.accessor.base.AccessorBase;
import com.inspur.edp.cef.entity.entity.IEntityDataCollection;
import java.lang.Override;
import com.inspur.edp.cef.api.dataType.entity.ICefEntity;
import com.inspur.edp.bff.core.entity.ViewObjectEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.IactivityNewView;
import com.inspur.edp.commonmodel.spi.AbstractEntityDataSerializer;
import com.inspur.edp.bff.spi.AbstractBffEntitySerConvertor;
import com.inspur.edp.commonmodel.spi.AbstractEntityDataDeSerializer;
import com.inspur.edp.bff.spi.AbstractBffEntityDeserConvertor;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.bff.spi.changeset.AbstractBffChangeJsonSerializer;
import com.inspur.edp.bff.spi.changeset.AbstractBffChangeJsonDeserializer;
import com.inspur.edp.cef.core.i18n.I18nResourceUtil;
import com.inspur.edp.cef.spi.entity.info.EnumValueInfo;
import com.inspur.edp.cef.spi.entity.resourceInfo.EntityResInfo;
import com.inspur.edp.cef.spi.entity.resourceInfo.ModelResInfo;
import com.inspur.edp.cef.api.request.RequestInfo;
import com.inspur.edp.bff.api.manager.IFSManager;
import com.inspur.edp.bff.spi.request.RequestConvertor;
import com.inspur.edp.cef.api.response.ResponseInfo;
import com.inspur.edp.bff.spi.response.ResponseConvertor;
import com.inspur.edp.bff.api.attribute.AbstractSourceConfig;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityFormNew_frmSourceConfig;
import com.inspur.edp.cef.entity.entity.IEntityData;
import com.inspur.edp.bff.api.dataprocessor.IChangeConvertor;
import com.inspur.edp.bff.api.dataprocessor.IDataConvertor;
import com.inspur.edp.bff.api.dataprocessor.IDefaultValueConvertor;
import java.lang.Class;
import java.lang.RuntimeException;
import com.inspur.edp.bff.spi.VMHelpConfig;
import java.util.ArrayList;
import com.inspur.edp.bff.spi.IHelpExtend;
import com.inspur.edp.bff.api.manager.assembler.IAssemblerManager;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frmgenvariable.activityFormNew_frmvariableManager;
import com.inspur.edp.cef.variable.api.manager.IVariableManager;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewFilterConvertor;
import com.inspur.edp.bff.api.dataprocessor.IFilterFieldConvertor;
import com.inspur.edp.cef.api.dataType.entity.ICefRootEntity;
import com.inspur.edp.bff.api.manager.context.QueryContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendQueryAssembler;
import com.inspur.edp.bff.api.manager.context.DataMapperContext;
import com.inspur.edp.bff.spi.assembler.AbstractDataMapperAssembler;
import com.inspur.edp.bff.api.manager.context.RetrieveContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendRetrieveAssembler;
import com.inspur.edp.bff.api.manager.context.RetrieveDefaultContext;
import com.inspur.edp.bff.spi.assembler.AbstractRetrieveDefaultAssembler;
import com.inspur.edp.bff.api.manager.context.ModifyContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendModifyAssembler;
import com.inspur.edp.bff.api.manager.context.DeleteContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendDeleteAssembler;
import com.inspur.edp.bff.api.manager.context.SaveContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendSaveAssembler;
import com.inspur.edp.bff.spi.action.changemapping.ChangeMappingAction;
import com.inspur.edp.bff.api.manager.context.ChangeMapperContext;
import com.inspur.edp.bff.spi.action.changemapping.ChangeReversalMappingAction;
import com.inspur.edp.bff.spi.assembler.AbstractChangeMapperAssembler;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmService;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmManager;
import com.inspur.edp.bff.api.manager.assembler.IExtendQueryAssembler;
import com.inspur.edp.bff.api.manager.assembler.IDataMapperAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendRetrieveAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendRetrieveDefaultAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendDeleteAssembler;
import com.inspur.edp.bff.api.manager.assembler.IChangeMapperAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendModifyAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendSaveAssembler;
import com.inspur.edp.bff.entity.changeset.ViewModelChangeset;
import com.inspur.edp.bff.spi.changeset.AbstractVMChangeConvertor;
public class activityFormNew_frmmanager extends com.inspur.edp.bff.core.manager.FSManager implements com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmService, IactivityFormNew_frm_Gen {
  public activityFormNew_frmmanager(  String funcSessionID){
    super(funcSessionID);
    addExtends();
  }
  public activityFormNew_frmmanager(){
    addExtends();
  }
  @Override protected String getVoId(){
    return "adae5fde-3dec-47d5-8ca6-0099585875b7";
  }
  @Override public AbstractSourceConfig getSourceConfigs(){
    return new activityFormNew_frmSourceConfig();
  }
  @Override public com.inspur.edp.cef.api.dataType.base.IAccessorCreator getAccessorCreator(){
    return new activityFormNew_frmAccessorCreator();
  }
  protected AbstractBffChangeJsonSerializer getChangeSerializer(){
    return new ChangeSerConvertor();
  }
  protected AbstractBffChangeJsonDeserializer getChangeDeserializer(){
    return new ChangeDeserConvertor();
  }
  @Override public com.inspur.edp.cef.spi.entity.resourceInfo.ModelResInfo getModelInfo(){
    return new activityFormNew_frmMgrResourceInfo();
  }
  @Override protected IEntityData innerCreateData(){
    com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frmgen.activityFormNew_frmData data=new com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frmgen.activityFormNew_frmData();
    return data;
  }
  @Override protected IChangeConvertor getChangeMapConvertor(){
    return new com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewChangeConvertor(this.getBffContext());
  }
  @Override protected IDataConvertor getDataConvertor(){
    return new com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewConvertor();
  }
  @Override protected IDefaultValueConvertor getDefaultValueConvertor(){
    return new com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewDefaultValueMapConvertor();
  }
  @Override public Class getDefaultValueType(){
    return com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityFormNew_frmDefaultValue.class;
  }
  @Override protected IEntityData innerCreateChildData(  String childCode){
    throw new java.lang.RuntimeException("不存在子表" + childCode);
  }
  @Override protected String getBECodeFromVM(  String vmObjectCode){
switch (vmObjectCode) {
case "activityNew":
      return "activityNew";
default :
    return null;
}
}
@Override protected String getVMCodeFromBE(String beObjectCode){
switch (beObjectCode) {
case "activityNew":
  return "activityNew";
default :
return "";
}
}
@Override protected String getHelpId(String codeName,String labelId){
switch (codeName + labelId) {
default :
throw new RuntimeException("给定的ElementID:" + labelId + "未能找到帮助配置信息");
}
}
@Override protected VMHelpConfig getHelpConfig(String codeName,String labelId){
switch (codeName + labelId) {
default :
return null;
}
}
@Override protected ArrayList<IHelpExtend> getHelpActions(String codeName,String labelId){
switch (codeName + labelId) {
default :
return new ArrayList<IHelpExtend>();
}
}
@Override public IAssemblerManager getAssemblerManager(){
return new activityFormNew_frmAssemblerManager();
}
protected AbstractBffEntitySerConvertor getDataJsonSerizlize(){
return new EntitySerConvertor();
}
@Override public IVariableManager createVariableManager(){
return new activityFormNew_frmvariableManager();
}
protected AbstractBffEntityDeserConvertor getDataJsonDeSerizlize(){
return new EntityDeserConvertor();
}
@Override public Class getChangeInfoType(){
return activityFormNew_frmChangeInfo.class;
}
public Class getRequsetType(){
return activityFormNew_frmRequestInfo.class;
}
public ResponseInfo createResponse(){
return new activityFormNew_frmResponseInfo();
}
@Override protected IFilterFieldConvertor getFilterConvertor(){
return new activityNewFilterConvertor();
}
@Override protected ICefRootEntity createVoEntity(String id){
return new activityFormNew_frm_activityNewVoEntity(id);
}
protected void addExtends(){
}
public String getVoNodeCode(String frontNodeCode){
switch (frontNodeCode) {
case "activityNew":
return "activityNew";
default :
return null;
}
}
}

