package com.inspur.gs.gsp.myapp.activitynew.activitynewgen;

import com.inspur.edp.bef.api.be.IBENodeEntityContext;
import com.inspur.edp.bef.core.determination.DeterminationContext;
import com.inspur.edp.bef.core.validation.ValidationContext;
import com.inspur.edp.cef.spi.determination.IDetermination;
import com.inspur.edp.cef.spi.validation.IValidation;
import com.inspur.edp.cef.entity.changeset.ModifyChangeDetail;
import com.inspur.edp.cef.entity.changeset.ValueObjModifyChangeDetail;
import com.inspur.edp.cef.entity.changeset.DeleteChangeDetail;
import com.inspur.edp.cef.entity.changeset.AddChangeDetail;
import com.inspur.edp.cef.entity.changeset.IChangeDetail;
import java.util.Map;
import com.inspur.edp.cef.entity.accessor.base.IAccessor;
import com.inspur.edp.cef.entity.accessor.base.ReadonlyDataException;
import java.util.HashMap;
import com.inspur.edp.cef.api.repository.GspDbDataType;
import com.inspur.edp.cef.entity.condition.SortCondition;
import java.lang.Cloneable;
import com.inspur.edp.cef.entity.entity.EntityDataCollection;
import java.lang.String;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeDeseiralizer;
import com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeSerializer;
import java.util.Date;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import java.math.BigDecimal;
import java.lang.Object;
import com.inspur.edp.cef.entity.entity.ICefData;
import java.util.List;
import java.util.ArrayList;
import com.inspur.edp.cef.core.validation.lengthvaladaptor.DecimalLengthValAdaptor;
import com.inspur.edp.cef.core.validation.lengthvaladaptor.StringLengthValAdaptor;
import com.inspur.edp.cef.core.validation.requiredvaladaptor.RequiredStringValAdaptor;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.core.activityNewBeforeSaveUQConstraintValidation;
import com.inspur.edp.cef.entity.accessor.base.AccessorBase;
import com.inspur.edp.cef.entity.entity.IEntityDataCollection;
import com.inspur.edp.cef.entity.entity.IEntityData;
import com.inspur.edp.bef.core.be.BENodeEntity;
import com.inspur.edp.bef.spi.entity.IDefaultValueDic;
import com.inspur.edp.bef.spi.entity.CodeRuleInfo;
import com.inspur.edp.bef.spi.entity.CodeRuleAssembler;
import com.inspur.edp.bef.core.be.BusinessEntity;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.bef.spi.entity.AbstractBizEntitySerializer;
import com.inspur.edp.bef.spi.entity.AbstractBizEntityDeSerializer;
import com.inspur.edp.bef.spi.entity.AbstractBizEntityChangeJsonSerializer;
import com.inspur.edp.bef.spi.entity.AbstractBizEntityChangeJsonDeSerializer;
import com.inspur.edp.cef.core.i18n.I18nResourceUtil;
import com.inspur.edp.cef.spi.entity.info.EnumValueInfo;
import com.inspur.edp.cef.spi.entity.resourceInfo.EntityResInfo;
import com.inspur.edp.cef.spi.entity.resourceInfo.ModelResInfo;
import com.inspur.edp.bef.api.be.IBusinessEntity;
import com.inspur.edp.cef.spi.determination.IEntityRTDtmAssembler;
import com.inspur.edp.cef.entity.UQConstraintConfig;
import com.inspur.edp.cef.variable.api.manager.IVariableManager;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewService;
import com.inspur.edp.bef.api.be.IBEManager;
import com.inspur.edp.bef.api.be.BEInfo;
import com.inspur.edp.bef.spi.extend.IBEManagerExtend;
import com.inspur.edp.bef.core.lcp.StandardLcp;
import com.inspur.edp.bef.core.determination.AbstractB4QueryDtmAssembler;
import com.inspur.edp.bef.core.determination.AbstractB4RetrieveDtmAssembler;
import java.lang.Override;
import com.inspur.edp.cef.api.repository.readerWriter.ICefReader;
import java.lang.Integer;
import com.inspur.edp.cef.repository.adaptor.EntityRelationalAdaptor;
import com.inspur.edp.cef.repository.dac.ChildEntityDac;
public class activityNewRDAcc extends com.inspur.edp.cef.core.data.RootEntityAccessor implements com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew {
  public activityNewRDAcc(  com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew data){
    super(data);
    Initialize();
  }
  @JsonProperty("location") @Override public String getLocation(){
    return getInnerData().getLocation();
  }
  @Override public void setLocation(  String value){
    throw new ReadonlyDataException();
  }
  @JsonProperty("id") @Override public String getID(){
    return getInnerData().getID();
  }
  @Override public void setID(  String value){
    throw new ReadonlyDataException();
  }
  @JsonProperty("version") @Override public Date getVersion(){
    return getInnerData().getVersion();
  }
  @Override public void setVersion(  Date value){
    throw new ReadonlyDataException();
  }
  @JsonProperty("code") @Override public String getCode(){
    return getInnerData().getCode();
  }
  @Override public void setCode(  String value){
    throw new ReadonlyDataException();
  }
  @JsonProperty("title") @Override public String getTitle(){
    return getInnerData().getTitle();
  }
  @Override public void setTitle(  String value){
    throw new ReadonlyDataException();
  }
  @JsonProperty("updateInfo") @Override public String getUpdateInfo(){
    return getInnerData().getUpdateInfo();
  }
  @Override public void setUpdateInfo(  String value){
    throw new ReadonlyDataException();
  }
  @JsonProperty("geoLng") @Override public BigDecimal getGeoLng(){
    return getInnerData().getGeoLng();
  }
  @Override public void setGeoLng(  BigDecimal value){
    throw new ReadonlyDataException();
  }
  @JsonProperty("geoLat") @Override public BigDecimal getGeoLat(){
    return getInnerData().getGeoLat();
  }
  @Override public void setGeoLat(  BigDecimal value){
    throw new ReadonlyDataException();
  }
  @Override public com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew getInnerData(){
    return (com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew)super.getInnerData();
  }
  public java.lang.String getNodeCode(){
    return "RootNode";
  }
  @Override public boolean equals(  Object obj){
    if (obj == null)     return false;
    com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew newObj=(com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew)obj;
    if (this.getLocation() == null) {
      if (newObj.getLocation() != null)       return false;
    }
 else     if (this.getLocation().equals(newObj.getLocation()) == false)     return false;
    if (this.getID() == null) {
      if (newObj.getID() != null)       return false;
    }
 else     if (this.getID().equals(newObj.getID()) == false)     return false;
    if (this.getVersion() == null) {
      if (newObj.getVersion() != null)       return false;
    }
 else     if (this.getVersion().equals(newObj.getVersion()) == false)     return false;
    if (this.getCode() == null) {
      if (newObj.getCode() != null)       return false;
    }
 else     if (this.getCode().equals(newObj.getCode()) == false)     return false;
    if (this.getTitle() == null) {
      if (newObj.getTitle() != null)       return false;
    }
 else     if (this.getTitle().equals(newObj.getTitle()) == false)     return false;
    if (this.getUpdateInfo() == null) {
      if (newObj.getUpdateInfo() != null)       return false;
    }
 else     if (this.getUpdateInfo().equals(newObj.getUpdateInfo()) == false)     return false;
    if (this.getGeoLng() == null) {
      if (newObj.getGeoLng() != null)       return false;
    }
 else     if (this.getGeoLng().equals(newObj.getGeoLng()) == false)     return false;
    if (this.getGeoLat() == null) {
      if (newObj.getGeoLat() != null)       return false;
    }
 else     if (this.getGeoLat().equals(newObj.getGeoLat()) == false)     return false;
    return true;
  }
  @Override public boolean getIsReadonly(){
    return true;
  }
  @Override protected java.lang.Object innerGetValue(  java.lang.String propName){
switch (propName) {
case "Location":
      return getLocation();
case "ID":
    return getID();
case "Version":
  return getVersion();
case "Code":
return getCode();
case "Title":
return getTitle();
case "UpdateInfo":
return getUpdateInfo();
case "GeoLng":
return getGeoLng();
case "GeoLat":
return getGeoLat();
default :
throw new RuntimeException("属性名不存在：" + propName);
}
}
@Override protected void innerSetValue(java.lang.String propName,java.lang.Object value){
switch (propName) {
case "Location":
setLocation((String)value);
break;
case "ID":
setID((String)value);
break;
case "Version":
setVersion((Date)value);
break;
case "Code":
setCode((String)value);
break;
case "Title":
setTitle((String)value);
break;
case "UpdateInfo":
setUpdateInfo((String)value);
break;
case "GeoLng":
setGeoLng((BigDecimal)value);
break;
case "GeoLat":
setGeoLat((BigDecimal)value);
break;
default :
throw new RuntimeException("属性名不存在：" + propName);
}
}
private void Initialize(){
initializeNested();
initializeChildCollection();
}
@Override public void copyCore(com.inspur.edp.cef.entity.accessor.base.AccessorBase accessor){
activityNewRDAcc result=(activityNewRDAcc)accessor;
}
@Override protected AccessorBase createNewObject(){
return new activityNewRDAcc(null);
}
@Override protected java.util.HashMap<String,IEntityDataCollection> innerGetChilds(){
HashMap<String,IEntityDataCollection> childs=new HashMap<>();
return childs;
}
@Override public IEntityDataCollection innerCreateAndSetChildCollection(java.lang.String childNodeCode){
throw new RuntimeException();
}
@Override protected void acceptChangeCore(com.inspur.edp.cef.entity.changeset.IChangeDetail change){
throw new UnsupportedOperationException();
}
@Override protected com.inspur.edp.cef.entity.entity.ICefData innerCreateChild(java.lang.String childCode){
throw new ReadonlyDataException();
}
@Override protected com.inspur.edp.cef.entity.entity.ICefData innerCopySelf(){
com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew data=(com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew)super.innerCopySelf();
return data;
}
public void initializeNested(){
}
private void initializeChildCollection(){
if (getInnerData() == null) return;
}
@Override protected void onInnerDataChange(){
super.onInnerDataChange();
initializeNested();
}
}

