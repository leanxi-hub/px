package com.inspur.gs.gsp.myapp.activitynew.activitynewgen;

import com.inspur.edp.bef.api.be.IBENodeEntityContext;
import com.inspur.edp.bef.core.determination.DeterminationContext;
import com.inspur.edp.bef.core.validation.ValidationContext;
import com.inspur.edp.cef.spi.determination.IDetermination;
import com.inspur.edp.cef.spi.validation.IValidation;
import com.inspur.edp.cef.entity.changeset.ModifyChangeDetail;
import com.inspur.edp.cef.entity.changeset.ValueObjModifyChangeDetail;
import com.inspur.edp.cef.entity.changeset.DeleteChangeDetail;
import com.inspur.edp.cef.entity.changeset.AddChangeDetail;
import com.inspur.edp.cef.entity.changeset.IChangeDetail;
import java.util.Map;
import com.inspur.edp.cef.entity.accessor.base.IAccessor;
import com.inspur.edp.cef.entity.accessor.base.ReadonlyDataException;
import java.util.HashMap;
import com.inspur.edp.cef.api.repository.GspDbDataType;
import com.inspur.edp.cef.entity.condition.SortCondition;
import java.lang.Cloneable;
import com.inspur.edp.cef.entity.entity.EntityDataCollection;
import java.lang.String;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeDeseiralizer;
import com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeSerializer;
import java.util.Date;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import java.math.BigDecimal;
import java.lang.Object;
import com.inspur.edp.cef.entity.entity.ICefData;
import java.util.List;
import java.util.ArrayList;
import com.inspur.edp.cef.core.validation.lengthvaladaptor.DecimalLengthValAdaptor;
import com.inspur.edp.cef.core.validation.lengthvaladaptor.StringLengthValAdaptor;
import com.inspur.edp.cef.core.validation.requiredvaladaptor.RequiredStringValAdaptor;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.core.activityNewBeforeSaveUQConstraintValidation;
import com.inspur.edp.cef.entity.accessor.base.AccessorBase;
import com.inspur.edp.cef.entity.entity.IEntityDataCollection;
import com.inspur.edp.cef.entity.entity.IEntityData;
import com.inspur.edp.bef.core.be.BENodeEntity;
import com.inspur.edp.bef.spi.entity.IDefaultValueDic;
import com.inspur.edp.bef.spi.entity.CodeRuleInfo;
import com.inspur.edp.bef.spi.entity.CodeRuleAssembler;
import com.inspur.edp.bef.core.be.BusinessEntity;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.bef.spi.entity.AbstractBizEntitySerializer;
import com.inspur.edp.bef.spi.entity.AbstractBizEntityDeSerializer;
import com.inspur.edp.bef.spi.entity.AbstractBizEntityChangeJsonSerializer;
import com.inspur.edp.bef.spi.entity.AbstractBizEntityChangeJsonDeSerializer;
import com.inspur.edp.cef.core.i18n.I18nResourceUtil;
import com.inspur.edp.cef.spi.entity.info.EnumValueInfo;
import com.inspur.edp.cef.spi.entity.resourceInfo.EntityResInfo;
import com.inspur.edp.cef.spi.entity.resourceInfo.ModelResInfo;
import com.inspur.edp.bef.api.be.IBusinessEntity;
import com.inspur.edp.cef.spi.determination.IEntityRTDtmAssembler;
import com.inspur.edp.cef.entity.UQConstraintConfig;
import com.inspur.edp.cef.variable.api.manager.IVariableManager;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewService;
import com.inspur.edp.bef.api.be.IBEManager;
import com.inspur.edp.bef.api.be.BEInfo;
import com.inspur.edp.bef.spi.extend.IBEManagerExtend;
import com.inspur.edp.bef.core.lcp.StandardLcp;
import com.inspur.edp.bef.core.determination.AbstractB4QueryDtmAssembler;
import com.inspur.edp.bef.core.determination.AbstractB4RetrieveDtmAssembler;
import java.lang.Override;
import com.inspur.edp.cef.api.repository.readerWriter.ICefReader;
import java.lang.Integer;
import com.inspur.edp.cef.repository.adaptor.EntityRelationalAdaptor;
import com.inspur.edp.cef.repository.dac.ChildEntityDac;
public class RootNodeSqlsvrAdaptor extends EntityRelationalAdaptor {
  @Override public String getTableAlias(){
    return tableAlias;
  }
  @Override public void setTableAlias(  String value){
    tableAlias=value;
  }
  @Override public String getPrimaryKey(){
    return "ID";
  }
  @Override protected java.lang.String getConfigId(){
    return "com.inspur.gs.gsp.myapp.activitynew.activityNew";
  }
  @Override public String getParentJoin(){
    return null;
  }
  @Override protected String getDboID(){
    return "11fd8e24-79e0-4c54-86c6-834947808d01";
  }
  @Override protected String getDeleteSqlBatch(){
    return "DELETE @TableName@ FROM @TableName@ activityNew ";
  }
  @Override protected String getGetDataByIdsSql(){
    return "SELECT %1$s FROM %2$s WHERE activityNew.ID IN%3$s";
  }
  @Override protected String getGetDataByIdSql(){
    return "SELECT %1$s FROM %2$s WHERE activityNew.ID = %3$s";
  }
  @Override protected String getJoinTableName(){
    return " LEFT OUTER JOIN %1$s ON %2$s = %3$s ";
  }
  @Override protected java.lang.String getNodeCode(){
    return "activityNew";
  }
  @Override protected String getVersionControlPropName(){
    return "Version";
  }
  private java.math.BigDecimal getGeoLatNormalPropertyValue(  com.inspur.edp.cef.api.repository.readerWriter.ICefReader reader){
    Object obj=reader.readValue("GeoLat");
    if (obj == null)     return null;
    return java.math.BigDecimal.valueOf(java.lang.Double.valueOf(obj.toString()));
  }
  private java.math.BigDecimal getGeoLngNormalPropertyValue(  com.inspur.edp.cef.api.repository.readerWriter.ICefReader reader){
    Object obj=reader.readValue("GeoLng");
    if (obj == null)     return null;
    return java.math.BigDecimal.valueOf(java.lang.Double.valueOf(obj.toString()));
  }
  private java.lang.String getUpdateInfoNormalPropertyValue(  com.inspur.edp.cef.api.repository.readerWriter.ICefReader reader){
    Object obj=reader.readValue("UpdateInfo");
    if (obj == null)     return com.inspur.edp.cef.entity.entity.EntityDataPropertyValueUtils.getStringPropertyDefaultValue();
    return obj.toString();
  }
  private java.lang.String getTitleNormalPropertyValue(  com.inspur.edp.cef.api.repository.readerWriter.ICefReader reader){
    Object obj=reader.readValue("Title");
    if (obj == null)     return com.inspur.edp.cef.entity.entity.EntityDataPropertyValueUtils.getStringPropertyDefaultValue();
    return obj.toString();
  }
  private java.lang.String getCodeNormalPropertyValue(  com.inspur.edp.cef.api.repository.readerWriter.ICefReader reader){
    Object obj=reader.readValue("Code");
    if (obj == null)     return com.inspur.edp.cef.entity.entity.EntityDataPropertyValueUtils.getStringPropertyDefaultValue();
    return obj.toString();
  }
  private Date getVersionNormalPropertyValue(  com.inspur.edp.cef.api.repository.readerWriter.ICefReader reader){
    Object obj=reader.readValue("Version");
    if (obj == null)     return com.inspur.edp.cef.entity.entity.EntityDataPropertyValueUtils.getDateTimePropertyDefaultValue();
    return (java.util.Date)obj;
  }
  private java.lang.String getIDNormalPropertyValue(  com.inspur.edp.cef.api.repository.readerWriter.ICefReader reader){
    Object obj=reader.readValue("ID");
    if (obj == null)     return com.inspur.edp.cef.entity.entity.EntityDataPropertyValueUtils.getStringPropertyDefaultValue();
    return obj.toString();
  }
  private java.lang.String getLocationNormalPropertyValue(  com.inspur.edp.cef.api.repository.readerWriter.ICefReader reader){
    Object obj=reader.readValue("Location");
    if (obj == null)     return com.inspur.edp.cef.entity.entity.EntityDataPropertyValueUtils.getStringPropertyDefaultValue();
    return obj.toString();
  }
  @Override public java.lang.Object readProperty(  java.lang.String propertyName,  com.inspur.edp.cef.api.repository.readerWriter.ICefReader reader){
switch (propertyName) {
case "GeoLat":
      return this.getGeoLatNormalPropertyValue(reader);
case "GeoLng":
    return this.getGeoLngNormalPropertyValue(reader);
case "UpdateInfo":
  return this.getUpdateInfoNormalPropertyValue(reader);
case "Title":
return this.getTitleNormalPropertyValue(reader);
case "Code":
return this.getCodeNormalPropertyValue(reader);
case "Version":
return this.getVersionNormalPropertyValue(reader);
case "ID":
return this.getIDNormalPropertyValue(reader);
case "Location":
return this.getLocationNormalPropertyValue(reader);
default :
throw new RuntimeException("找不到属性名" + propertyName);
}
}
@Override protected void initAssociations(){
}
@Override protected java.util.ArrayList<com.inspur.edp.cef.entity.condition.FilterCondition> getDefaultFilterCondition(){
return null;
}
@Override public com.inspur.edp.cef.entity.entity.ICefData createInstance(ICefReader reader){
activityNewData entity=new activityNewData();
if (reader.hasProperty("Location")) {
entity.setLocation(getLocationNormalPropertyValue(reader));
}
if (reader.hasProperty("ID")) {
entity.setID(getIDNormalPropertyValue(reader));
}
if (reader.hasProperty("Version")) {
entity.setVersion(getVersionNormalPropertyValue(reader));
}
if (reader.hasProperty("Code")) {
entity.setCode(getCodeNormalPropertyValue(reader));
}
if (reader.hasProperty("Title")) {
entity.setTitle(getTitleNormalPropertyValue(reader));
}
if (reader.hasProperty("UpdateInfo")) {
entity.setUpdateInfo(getUpdateInfoNormalPropertyValue(reader));
}
if (reader.hasProperty("GeoLng")) {
entity.setGeoLng(getGeoLngNormalPropertyValue(reader));
}
if (reader.hasProperty("GeoLat")) {
entity.setGeoLat(getGeoLatNormalPropertyValue(reader));
}
return entity;
}
@Override protected void initColumns(){
super.addColumn("ID","ID",GspDbDataType.VarChar,36,0,null,com.inspur.edp.cef.repository.typetransprocesser.VarcharTransProcesser.getInstacne(),true,false,false,false,false,false,"ID",false);
super.addColumn("Version","Version",GspDbDataType.DateTime,0,0,null,com.inspur.edp.cef.repository.typetransprocesser.DateTimeTransProcesser.getInstacne(),false,false,false,false,false,false,"Version",false);
super.addColumn("Code","Code",GspDbDataType.VarChar,36,0,null,com.inspur.edp.cef.repository.typetransprocesser.VarcharTransProcesser.getInstacne(),false,false,false,false,false,false,"Code",false);
super.addColumn("Title","Title",GspDbDataType.VarChar,1024,0,null,com.inspur.edp.cef.repository.typetransprocesser.VarcharTransProcesser.getInstacne(),false,false,false,false,false,false,"Title",false);
super.addColumn("Location","Location",GspDbDataType.VarChar,1024,0,null,com.inspur.edp.cef.repository.typetransprocesser.VarcharTransProcesser.getInstacne(),false,false,false,false,false,false,"Location",false);
super.addColumn("GeoLng","GeoLng",GspDbDataType.Decimal,0,18,null,com.inspur.edp.cef.repository.typetransprocesser.DecimalTransProcesser.getInstacne(),false,false,false,false,false,false,"GeoLng",false);
super.addColumn("GeoLat","GeoLat",GspDbDataType.Decimal,0,18,null,com.inspur.edp.cef.repository.typetransprocesser.DecimalTransProcesser.getInstacne(),false,false,false,false,false,false,"GeoLat",false);
super.addColumn("UpdateInfo","UpdateInfo",GspDbDataType.VarChar,36,0,null,com.inspur.edp.cef.repository.typetransprocesser.VarcharTransProcesser.getInstacne(),false,false,false,false,false,false,"UpdateInfo",false);
}
@Override protected Object getPropertyChangeValue(String propertyName,Object propertyValue){
switch (propertyName) {
default :
return propertyValue;
}
}
@Override protected ArrayList<SortCondition> getDefaultSortCondition(){
return null;
}
@Override public Object getPersistenceValue(String colName,ICefData data){
switch (colName) {
case "ID":
return this.getContainColumns().getItem("ID").getTypeTransProcesser().transType(((IactivityNew)data).getID());
case "Version":
return this.getContainColumns().getItem("Version").getTypeTransProcesser().transType(((IactivityNew)data).getVersion());
case "Code":
return this.getContainColumns().getItem("Code").getTypeTransProcesser().transType(((IactivityNew)data).getCode());
case "Title":
return this.getContainColumns().getItem("Title").getTypeTransProcesser().transType(((IactivityNew)data).getTitle());
case "Location":
return this.getContainColumns().getItem("Location").getTypeTransProcesser().transType(((IactivityNew)data).getLocation());
case "GeoLng":
return this.getContainColumns().getItem("GeoLng").getTypeTransProcesser().transType(((IactivityNew)data).getGeoLng(),true);
case "GeoLat":
return this.getContainColumns().getItem("GeoLat").getTypeTransProcesser().transType(((IactivityNew)data).getGeoLat(),true);
case "UpdateInfo":
return this.getContainColumns().getItem("UpdateInfo").getTypeTransProcesser().transType(((IactivityNew)data).getUpdateInfo());
default :
throw new RuntimeException();
}
}
@Override protected HashMap<String,Integer> getPropertyColumnMapping(){
return propIndexMappingDict;
}
@Override protected boolean hasPropColumnMappping(){
return propIndexMappingDict != null;
}
@Override protected void setPropertyColumnMapping(HashMap<String,Integer> mappingDict){
propIndexMappingDict=mappingDict;
}
@Override protected String innerGetDeleteSql(){
return "DELETE @TableName@ FROM @TableName@ activityNew ";
}
@Override protected String innerGetInsertSql(){
return "INSERT INTO @TableName@ (ID, Version, Code, Title, Location, GeoLng, GeoLat, UpdateInfo) VALUES(?0, ?1, ?2, ?3, ?4, ?5, ?6, ?7) ";
}
@Override protected String innerGetModifySql(){
return "Update @TableName@ Set";
}
private static HashMap<String,Integer> propIndexMappingDict;
private String tableAlias="activityNew";
}

