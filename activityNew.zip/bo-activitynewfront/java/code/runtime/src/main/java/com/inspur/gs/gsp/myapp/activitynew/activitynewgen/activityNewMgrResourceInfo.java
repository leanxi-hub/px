package com.inspur.gs.gsp.myapp.activitynew.activitynewgen;

import com.inspur.edp.bef.api.be.IBENodeEntityContext;
import com.inspur.edp.bef.core.determination.DeterminationContext;
import com.inspur.edp.bef.core.validation.ValidationContext;
import com.inspur.edp.cef.spi.determination.IDetermination;
import com.inspur.edp.cef.spi.validation.IValidation;
import com.inspur.edp.cef.entity.changeset.ModifyChangeDetail;
import com.inspur.edp.cef.entity.changeset.ValueObjModifyChangeDetail;
import com.inspur.edp.cef.entity.changeset.DeleteChangeDetail;
import com.inspur.edp.cef.entity.changeset.AddChangeDetail;
import com.inspur.edp.cef.entity.changeset.IChangeDetail;
import java.util.Map;
import com.inspur.edp.cef.entity.accessor.base.IAccessor;
import com.inspur.edp.cef.entity.accessor.base.ReadonlyDataException;
import java.util.HashMap;
import com.inspur.edp.cef.api.repository.GspDbDataType;
import com.inspur.edp.cef.entity.condition.SortCondition;
import java.lang.Cloneable;
import com.inspur.edp.cef.entity.entity.EntityDataCollection;
import java.lang.String;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeDeseiralizer;
import com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeSerializer;
import java.util.Date;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import java.math.BigDecimal;
import java.lang.Object;
import com.inspur.edp.cef.entity.entity.ICefData;
import java.util.List;
import java.util.ArrayList;
import com.inspur.edp.cef.core.validation.lengthvaladaptor.DecimalLengthValAdaptor;
import com.inspur.edp.cef.core.validation.lengthvaladaptor.StringLengthValAdaptor;
import com.inspur.edp.cef.core.validation.requiredvaladaptor.RequiredStringValAdaptor;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.core.activityNewBeforeSaveUQConstraintValidation;
import com.inspur.edp.cef.entity.accessor.base.AccessorBase;
import com.inspur.edp.cef.entity.entity.IEntityDataCollection;
import com.inspur.edp.cef.entity.entity.IEntityData;
import com.inspur.edp.bef.core.be.BENodeEntity;
import com.inspur.edp.bef.spi.entity.IDefaultValueDic;
import com.inspur.edp.bef.spi.entity.CodeRuleInfo;
import com.inspur.edp.bef.spi.entity.CodeRuleAssembler;
import com.inspur.edp.bef.core.be.BusinessEntity;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.bef.spi.entity.AbstractBizEntitySerializer;
import com.inspur.edp.bef.spi.entity.AbstractBizEntityDeSerializer;
import com.inspur.edp.bef.spi.entity.AbstractBizEntityChangeJsonSerializer;
import com.inspur.edp.bef.spi.entity.AbstractBizEntityChangeJsonDeSerializer;
import com.inspur.edp.cef.core.i18n.I18nResourceUtil;
import com.inspur.edp.cef.spi.entity.info.EnumValueInfo;
import com.inspur.edp.cef.spi.entity.resourceInfo.EntityResInfo;
import com.inspur.edp.cef.spi.entity.resourceInfo.ModelResInfo;
import com.inspur.edp.bef.api.be.IBusinessEntity;
import com.inspur.edp.cef.spi.determination.IEntityRTDtmAssembler;
import com.inspur.edp.cef.entity.UQConstraintConfig;
import com.inspur.edp.cef.variable.api.manager.IVariableManager;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewService;
import com.inspur.edp.bef.api.be.IBEManager;
import com.inspur.edp.bef.api.be.BEInfo;
import com.inspur.edp.bef.spi.extend.IBEManagerExtend;
import com.inspur.edp.bef.core.lcp.StandardLcp;
import com.inspur.edp.bef.core.determination.AbstractB4QueryDtmAssembler;
import com.inspur.edp.bef.core.determination.AbstractB4RetrieveDtmAssembler;
import java.lang.Override;
import com.inspur.edp.cef.api.repository.readerWriter.ICefReader;
import java.lang.Integer;
import com.inspur.edp.cef.repository.adaptor.EntityRelationalAdaptor;
import com.inspur.edp.cef.repository.dac.ChildEntityDac;
public class activityNewMgrResourceInfo extends ModelResInfo {
  @Override public String getResourceMetaId(){
    return "feece398-e594-44bf-86bb-3907e1a345a2";
  }
  @Override public String getRootNodeCode(){
    return "activityNew";
  }
  @Override public EntityResInfo getCustomResource(  java.lang.String entityName){
switch (entityName.toLowerCase()) {
case "activitynew":
case "rootnode":
      return new RootNodeEntityResourceInfo();
default :
    throw new RuntimeException("无效节点编号：" + entityName);
}
}
@Override public String getModelDispalyName(){
return I18nResourceUtil.getResourceItemValue("myapp","feece398-e594-44bf-86bb-3907e1a345a2","Inspur.GS.Gsp.myapp.activityNew.activityNew.Name");
}
}

