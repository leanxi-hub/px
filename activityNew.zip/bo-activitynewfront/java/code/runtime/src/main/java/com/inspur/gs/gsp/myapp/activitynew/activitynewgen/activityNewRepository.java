package com.inspur.gs.gsp.myapp.activitynew.activitynewgen;

import com.inspur.edp.bef.api.be.IBENodeEntityContext;
import com.inspur.edp.bef.core.determination.DeterminationContext;
import com.inspur.edp.bef.core.validation.ValidationContext;
import com.inspur.edp.cef.spi.determination.IDetermination;
import com.inspur.edp.cef.spi.validation.IValidation;
import com.inspur.edp.cef.entity.changeset.ModifyChangeDetail;
import com.inspur.edp.cef.entity.changeset.ValueObjModifyChangeDetail;
import com.inspur.edp.cef.entity.changeset.DeleteChangeDetail;
import com.inspur.edp.cef.entity.changeset.AddChangeDetail;
import com.inspur.edp.cef.entity.changeset.IChangeDetail;
import java.util.Map;
import com.inspur.edp.cef.entity.accessor.base.IAccessor;
import com.inspur.edp.cef.entity.accessor.base.ReadonlyDataException;
import java.util.HashMap;
import com.inspur.edp.cef.api.repository.GspDbDataType;
import com.inspur.edp.cef.entity.condition.SortCondition;
import java.lang.Cloneable;
import com.inspur.edp.cef.entity.entity.EntityDataCollection;
import java.lang.String;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeDeseiralizer;
import com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeSerializer;
import java.util.Date;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import java.math.BigDecimal;
import java.lang.Object;
import com.inspur.edp.cef.entity.entity.ICefData;
import java.util.List;
import java.util.ArrayList;
import com.inspur.edp.cef.core.validation.lengthvaladaptor.DecimalLengthValAdaptor;
import com.inspur.edp.cef.core.validation.lengthvaladaptor.StringLengthValAdaptor;
import com.inspur.edp.cef.core.validation.requiredvaladaptor.RequiredStringValAdaptor;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.core.activityNewBeforeSaveUQConstraintValidation;
import com.inspur.edp.cef.entity.accessor.base.AccessorBase;
import com.inspur.edp.cef.entity.entity.IEntityDataCollection;
import com.inspur.edp.cef.entity.entity.IEntityData;
import com.inspur.edp.bef.core.be.BENodeEntity;
import com.inspur.edp.bef.spi.entity.IDefaultValueDic;
import com.inspur.edp.bef.spi.entity.CodeRuleInfo;
import com.inspur.edp.bef.spi.entity.CodeRuleAssembler;
import com.inspur.edp.bef.core.be.BusinessEntity;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.bef.spi.entity.AbstractBizEntitySerializer;
import com.inspur.edp.bef.spi.entity.AbstractBizEntityDeSerializer;
import com.inspur.edp.bef.spi.entity.AbstractBizEntityChangeJsonSerializer;
import com.inspur.edp.bef.spi.entity.AbstractBizEntityChangeJsonDeSerializer;
import com.inspur.edp.cef.core.i18n.I18nResourceUtil;
import com.inspur.edp.cef.spi.entity.info.EnumValueInfo;
import com.inspur.edp.cef.spi.entity.resourceInfo.EntityResInfo;
import com.inspur.edp.cef.spi.entity.resourceInfo.ModelResInfo;
import com.inspur.edp.bef.api.be.IBusinessEntity;
import com.inspur.edp.cef.spi.determination.IEntityRTDtmAssembler;
import com.inspur.edp.cef.entity.UQConstraintConfig;
import com.inspur.edp.cef.variable.api.manager.IVariableManager;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewService;
import com.inspur.edp.bef.api.be.IBEManager;
import com.inspur.edp.bef.api.be.BEInfo;
import com.inspur.edp.bef.spi.extend.IBEManagerExtend;
import com.inspur.edp.bef.core.lcp.StandardLcp;
import com.inspur.edp.bef.core.determination.AbstractB4QueryDtmAssembler;
import com.inspur.edp.bef.core.determination.AbstractB4RetrieveDtmAssembler;
import java.lang.Override;
import com.inspur.edp.cef.api.repository.readerWriter.ICefReader;
import java.lang.Integer;
import com.inspur.edp.cef.repository.adaptor.EntityRelationalAdaptor;
import com.inspur.edp.cef.repository.dac.ChildEntityDac;
public class activityNewRepository extends com.inspur.edp.cef.repository.repo.BaseRootRepository {
  @Override protected com.inspur.edp.cef.repository.dac.MainEntityDac getMainEntityDac(){
    if (mainDac == null) {
      mainDac=new activityNewdac();
    }
    return mainDac;
  }
  private com.inspur.edp.cef.repository.dac.MainEntityDac mainDac;
}

