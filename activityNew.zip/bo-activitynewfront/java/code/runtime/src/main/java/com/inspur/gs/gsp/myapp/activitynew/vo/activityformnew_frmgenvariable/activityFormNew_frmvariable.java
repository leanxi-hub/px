package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frmgenvariable;

import com.inspur.edp.cef.spi.determination.IDetermination;
import com.inspur.edp.cef.entity.accessor.base.ReadonlyDataException;
import java.util.HashMap;
import com.inspur.edp.cef.variable.api.variable.IVariable;
import com.inspur.edp.cef.entity.entity.IValueObjData;
import java.lang.Cloneable;
import com.inspur.edp.cef.entity.entity.EntityDataCollection;
import java.lang.Object;
import com.inspur.edp.cef.entity.accessor.base.AccessorBase;
import com.inspur.edp.cef.entity.changeset.ValueObjModifyChangeDetail;
import com.inspur.edp.cef.entity.entity.ICefData;
import java.util.List;
import com.inspur.edp.cef.api.dataType.valueObj.ICefValueObjContext;
import java.util.ArrayList;
import com.inspur.edp.cef.variable.api.variable.IVariableContext;
import com.inspur.edp.cef.variable.core.variable.AbstractVariable;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.cef.spi.jsonser.valueobj.AbstractValueObjSerializer;
public class activityFormNew_frmvariable extends AbstractVariable implements com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.Variable.IactivityFormNew_frmVariableAllEntityInterface, com.inspur.edp.cef.api.dataType.valueObj.ICefValueObject, IVariable {
  public activityFormNew_frmvariable(  IVariableContext context){
    super(context);
  }
  @Override protected com.inspur.edp.cef.spi.determination.IValueObjRTDtmAssembler createAfterModifyDtmAssembler(){
    return new activityFormNew_frmvariableAfterModifyDtm();
  }
  @Override public void assignDefaultValue(  com.inspur.edp.cef.entity.entity.IEntityData data){
    activityFormNew_frmVariableAcc realData=(activityFormNew_frmVariableAcc)data;
  }
}

