package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frmgen;

import com.inspur.edp.cef.spi.determination.IDetermination;
import com.inspur.edp.cef.spi.validation.IValidation;
import com.inspur.edp.cef.entity.changeset.ModifyChangeDetail;
import com.inspur.edp.cef.entity.changeset.ValueObjModifyChangeDetail;
import com.inspur.edp.cef.entity.changeset.DeleteChangeDetail;
import com.inspur.edp.cef.entity.changeset.AddChangeDetail;
import com.inspur.edp.cef.entity.changeset.IChangeDetail;
import java.util.Map;
import com.inspur.edp.cef.entity.accessor.base.IAccessor;
import com.inspur.edp.cef.entity.accessor.base.ReadonlyDataException;
import java.util.HashMap;
import com.inspur.edp.bff.spi.action.query.BeforeQueryAction;
import com.inspur.edp.bff.spi.action.query.AbstractQueryAction;
import com.inspur.edp.bff.spi.action.query.AfterQueryAction;
import com.inspur.edp.bff.spi.action.datamapping.DataMappingAction;
import com.inspur.edp.bff.spi.action.datamapping.DataReversalMappingAction;
import com.inspur.edp.bff.spi.action.retrieve.BeforeRetrieveAction;
import com.inspur.edp.bff.spi.action.retrieve.AbstractRetrieveAction;
import com.inspur.edp.bff.spi.action.retrieve.AfterRetrieveAction;
import com.inspur.edp.bff.spi.action.retrievedefault.BeforeRetrieveDefaultAction;
import com.inspur.edp.bff.spi.action.retrievedefault.AbstractRetrieveDefaultAction;
import com.inspur.edp.bff.spi.action.retrievedefault.AfterRetrieveDefaultAction;
import com.inspur.edp.bff.spi.action.delete.BeforeDeleteAction;
import com.inspur.edp.bff.spi.action.delete.AbstractDeleteAction;
import com.inspur.edp.bff.spi.action.delete.AfterDeleteAction;
import com.inspur.edp.bff.spi.action.multidelete.BeforeMultiDeleteAction;
import com.inspur.edp.bff.spi.action.multidelete.AbstractMultiDeleteAction;
import com.inspur.edp.bff.spi.action.multidelete.AfterMultiDeleteAction;
import com.inspur.edp.bff.spi.action.modify.BeforeModifyAction;
import com.inspur.edp.bff.spi.action.modify.AbstractModifyAction;
import com.inspur.edp.bff.spi.action.modify.AfterModifyAction;
import com.inspur.edp.bff.spi.action.save.BeforeSaveAction;
import com.inspur.edp.bff.spi.action.save.AfterSaveAction;
import java.lang.Cloneable;
import com.inspur.edp.cef.entity.entity.EntityDataCollection;
import java.lang.String;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeDeseiralizer;
import com.inspur.edp.cef.spi.jsonser.abstractcefchange.BefDateTimeSerializer;
import java.util.Date;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import java.math.BigDecimal;
import java.lang.Object;
import com.inspur.edp.cef.entity.entity.ICefData;
import com.inspur.edp.cef.entity.accessor.base.AccessorBase;
import com.inspur.edp.cef.entity.entity.IEntityDataCollection;
import java.lang.Override;
import com.inspur.edp.cef.api.dataType.entity.ICefEntity;
import com.inspur.edp.bff.core.entity.ViewObjectEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.IactivityNewView;
import com.inspur.edp.commonmodel.spi.AbstractEntityDataSerializer;
import com.inspur.edp.bff.spi.AbstractBffEntitySerConvertor;
import com.inspur.edp.commonmodel.spi.AbstractEntityDataDeSerializer;
import com.inspur.edp.bff.spi.AbstractBffEntityDeserConvertor;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.bff.spi.changeset.AbstractBffChangeJsonSerializer;
import com.inspur.edp.bff.spi.changeset.AbstractBffChangeJsonDeserializer;
import com.inspur.edp.cef.core.i18n.I18nResourceUtil;
import com.inspur.edp.cef.spi.entity.info.EnumValueInfo;
import com.inspur.edp.cef.spi.entity.resourceInfo.EntityResInfo;
import com.inspur.edp.cef.spi.entity.resourceInfo.ModelResInfo;
import com.inspur.edp.cef.api.request.RequestInfo;
import com.inspur.edp.bff.api.manager.IFSManager;
import com.inspur.edp.bff.spi.request.RequestConvertor;
import com.inspur.edp.cef.api.response.ResponseInfo;
import com.inspur.edp.bff.spi.response.ResponseConvertor;
import com.inspur.edp.bff.api.attribute.AbstractSourceConfig;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityFormNew_frmSourceConfig;
import com.inspur.edp.cef.entity.entity.IEntityData;
import com.inspur.edp.bff.api.dataprocessor.IChangeConvertor;
import com.inspur.edp.bff.api.dataprocessor.IDataConvertor;
import com.inspur.edp.bff.api.dataprocessor.IDefaultValueConvertor;
import java.lang.Class;
import java.lang.RuntimeException;
import com.inspur.edp.bff.spi.VMHelpConfig;
import java.util.ArrayList;
import com.inspur.edp.bff.spi.IHelpExtend;
import com.inspur.edp.bff.api.manager.assembler.IAssemblerManager;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frmgenvariable.activityFormNew_frmvariableManager;
import com.inspur.edp.cef.variable.api.manager.IVariableManager;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewFilterConvertor;
import com.inspur.edp.bff.api.dataprocessor.IFilterFieldConvertor;
import com.inspur.edp.cef.api.dataType.entity.ICefRootEntity;
import com.inspur.edp.bff.api.manager.context.QueryContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendQueryAssembler;
import com.inspur.edp.bff.api.manager.context.DataMapperContext;
import com.inspur.edp.bff.spi.assembler.AbstractDataMapperAssembler;
import com.inspur.edp.bff.api.manager.context.RetrieveContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendRetrieveAssembler;
import com.inspur.edp.bff.api.manager.context.RetrieveDefaultContext;
import com.inspur.edp.bff.spi.assembler.AbstractRetrieveDefaultAssembler;
import com.inspur.edp.bff.api.manager.context.ModifyContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendModifyAssembler;
import com.inspur.edp.bff.api.manager.context.DeleteContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendDeleteAssembler;
import com.inspur.edp.bff.api.manager.context.SaveContext;
import com.inspur.edp.bff.spi.assembler.AbstractExtendSaveAssembler;
import com.inspur.edp.bff.spi.action.changemapping.ChangeMappingAction;
import com.inspur.edp.bff.api.manager.context.ChangeMapperContext;
import com.inspur.edp.bff.spi.action.changemapping.ChangeReversalMappingAction;
import com.inspur.edp.bff.spi.assembler.AbstractChangeMapperAssembler;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmService;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmManager;
import com.inspur.edp.bff.api.manager.assembler.IExtendQueryAssembler;
import com.inspur.edp.bff.api.manager.assembler.IDataMapperAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendRetrieveAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendRetrieveDefaultAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendDeleteAssembler;
import com.inspur.edp.bff.api.manager.assembler.IChangeMapperAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendModifyAssembler;
import com.inspur.edp.bff.api.manager.assembler.IExtendSaveAssembler;
import com.inspur.edp.bff.entity.changeset.ViewModelChangeset;
import com.inspur.edp.bff.spi.changeset.AbstractVMChangeConvertor;
public class RootNodeEntityResourceInfo extends EntityResInfo {
  @Override public String getUniqueConstraintMessage(  java.lang.String uniqueConCode){
switch (uniqueConCode) {
default :
      throw new RuntimeException("无效的唯一性约束编码" + uniqueConCode);
  }
}
@Override public String getEntityCode(){
  return "RootNode";
}
@Override public String getDisplayName(){
  return I18nResourceUtil.getResourceItemValue("myapp","3c8223ca-6136-400e-8a1e-35612a0201b1","Inspur.GS.Gsp.myapp.activityNew.Vo.activityFormNew_frm.activityNew.Name");
}
@Override public String getPropertyDispalyName(java.lang.String propName){
switch (propName) {
case "GeoLat":
    return I18nResourceUtil.getResourceItemValue("myapp","3c8223ca-6136-400e-8a1e-35612a0201b1","Inspur.GS.Gsp.myapp.activityNew.Vo.activityFormNew_frm.activityNew.GeoLat.Name");
case "Version":
  return I18nResourceUtil.getResourceItemValue("myapp","3c8223ca-6136-400e-8a1e-35612a0201b1","Inspur.GS.Gsp.myapp.activityNew.Vo.activityFormNew_frm.activityNew.Version.Name");
case "Title":
return I18nResourceUtil.getResourceItemValue("myapp","3c8223ca-6136-400e-8a1e-35612a0201b1","Inspur.GS.Gsp.myapp.activityNew.Vo.activityFormNew_frm.activityNew.Title.Name");
case "ID":
return I18nResourceUtil.getResourceItemValue("myapp","3c8223ca-6136-400e-8a1e-35612a0201b1","Inspur.GS.Gsp.myapp.activityNew.Vo.activityFormNew_frm.activityNew.ID.Name");
case "Code":
return I18nResourceUtil.getResourceItemValue("myapp","3c8223ca-6136-400e-8a1e-35612a0201b1","Inspur.GS.Gsp.myapp.activityNew.Vo.activityFormNew_frm.activityNew.Code.Name");
case "GeoLng":
return I18nResourceUtil.getResourceItemValue("myapp","3c8223ca-6136-400e-8a1e-35612a0201b1","Inspur.GS.Gsp.myapp.activityNew.Vo.activityFormNew_frm.activityNew.GeoLng.Name");
case "UpdateInfo":
return I18nResourceUtil.getResourceItemValue("myapp","3c8223ca-6136-400e-8a1e-35612a0201b1","Inspur.GS.Gsp.myapp.activityNew.Vo.activityFormNew_frm.activityNew.UpdateInfo.Name");
case "Location":
return I18nResourceUtil.getResourceItemValue("myapp","3c8223ca-6136-400e-8a1e-35612a0201b1","Inspur.GS.Gsp.myapp.activityNew.Vo.activityFormNew_frm.activityNew.Location.Name");
default :
throw new RuntimeException("无效的属性名称" + propName);
}
}
@Override public String getEnumPropertyDispalyValue(java.lang.String propName,java.lang.String enumKey){
switch (propName) {
default :
throw new RuntimeException("当前属性不是枚举字段，或不存在该属性名称" + propName);
}
}
@Override public EnumValueInfo getPropEnumInfo(java.lang.String propName,java.lang.String enumKey){
switch (propName) {
default :
throw new RuntimeException("当前属性不是枚举字段，或不存在该属性名称：" + propName);
}
}
public java.util.List<EnumValueInfo> getPropEnumInfos(java.lang.String propName){
ArrayList<EnumValueInfo> list=new ArrayList();
switch (propName) {
default :
throw new RuntimeException("当前属性不是枚举字段，或不存在该属性名称：" + propName);
}
}
@Override public String getAssoRefPropertyDisplay(java.lang.String propName,java.lang.String refPropName){
switch (propName) {
default :
throw new RuntimeException("无效的属性名称" + refPropName);
}
}
}

