package com.inspur.gs.gsp.myapp.activitynew.activitynewgenvariable;

import com.inspur.edp.cef.spi.determination.IDetermination;
import com.inspur.edp.cef.entity.accessor.base.ReadonlyDataException;
import java.util.HashMap;
import com.inspur.edp.bef.api.be.BEInfo;
import com.inspur.edp.cef.variable.api.variable.IVariable;
import com.inspur.edp.cef.entity.entity.IValueObjData;
import java.lang.Cloneable;
import com.inspur.edp.cef.entity.entity.EntityDataCollection;
import java.lang.Object;
import com.inspur.edp.cef.entity.accessor.base.AccessorBase;
import com.inspur.edp.cef.entity.changeset.ValueObjModifyChangeDetail;
import com.inspur.edp.cef.entity.entity.ICefData;
import java.util.List;
import com.inspur.edp.cef.api.dataType.valueObj.ICefValueObjContext;
import java.util.ArrayList;
import com.inspur.edp.cef.variable.api.variable.IVariableContext;
import com.inspur.edp.cef.variable.core.variable.AbstractVariable;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.cef.spi.jsonser.valueobj.AbstractValueObjSerializer;
public class activityNewvariableChangeSerConvertor extends com.inspur.edp.cef.spi.jsonser.valueobj.AbstractValueObjChangeSerializer {
  public activityNewvariableChangeSerConvertor(){
    super(getTypes());
  }
  public static ArrayList<AbstractValueObjSerializer> getTypes(){
    ArrayList<AbstractValueObjSerializer> list=new ArrayList<>();
    list.add(new com.inspur.gs.gsp.myapp.activitynew.activitynew.core.Variable.activityNewVariableSerItem());
    return list;
  }
}

