package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frmgenvariable;

import com.inspur.edp.cef.spi.determination.IDetermination;
import com.inspur.edp.cef.entity.accessor.base.ReadonlyDataException;
import java.util.HashMap;
import com.inspur.edp.cef.variable.api.variable.IVariable;
import com.inspur.edp.cef.entity.entity.IValueObjData;
import java.lang.Cloneable;
import com.inspur.edp.cef.entity.entity.EntityDataCollection;
import java.lang.Object;
import com.inspur.edp.cef.entity.accessor.base.AccessorBase;
import com.inspur.edp.cef.entity.changeset.ValueObjModifyChangeDetail;
import com.inspur.edp.cef.entity.entity.ICefData;
import java.util.List;
import com.inspur.edp.cef.api.dataType.valueObj.ICefValueObjContext;
import java.util.ArrayList;
import com.inspur.edp.cef.variable.api.variable.IVariableContext;
import com.inspur.edp.cef.variable.core.variable.AbstractVariable;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.cef.spi.jsonser.valueobj.AbstractValueObjSerializer;
public class activityFormNew_frmvariableManager extends com.inspur.edp.cef.variable.core.manager.AbstractVariableManager implements com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.Variable.IactivityFormNew_frmVariableService {
  @Override public com.inspur.edp.cef.api.dataType.base.IAccessorCreator getAccessorCreator(){
    return new activityFormNew_frmvariableAccessorCreator();
  }
  @Override protected com.inspur.edp.cef.spi.jsonser.abstractcefchange.AbstractCefChangeSerializer getChangeSerializer(){
    return new activityFormNew_frmvariableChangeSerConvertor();
  }
  @Override protected com.inspur.edp.cef.spi.jsonser.abstractcefchange.AbstractCefChangeJsonDeserializer getChangeDeserializer(){
    return new activityFormNew_frmvariableor();
  }
  @Override protected com.inspur.edp.cef.entity.entity.IValueObjData createDataCore(){
    return new activityFormNew_frmvariableData();
  }
  @Override public AbstractVariable createVariable(  IVariableContext ctx){
    return new activityFormNew_frmvariable(ctx);
  }
}

