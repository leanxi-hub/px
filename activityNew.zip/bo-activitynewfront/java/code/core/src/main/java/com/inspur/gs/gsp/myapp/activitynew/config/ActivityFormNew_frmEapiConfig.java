package com.inspur.gs.gsp.myapp.activitynew.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean;
import com.inspur.gs.gsp.myapp.activitynew.rest.ActivityFormNew_frmServiceImpl;
import com.inspur.gs.gsp.myapp.activitynew.rest.ActivityFormNew_frmService;
import io.iec.edp.caf.rest.RESTEndpoint;

@Configuration("com.inspur.gs.gsp.myapp.activitynew.config.ActivityFormNew_frmEapiConfig")
public class ActivityFormNew_frmEapiConfig {

  @Bean("2a7d0ea5-55ef-4688-a7e2-2dcb353dbd79Server")
  public ActivityFormNew_frmService activityFormNew_frmServiceServer() {
    return new ActivityFormNew_frmServiceImpl();
  }

  @Bean("2a7d0ea5-55ef-4688-a7e2-2dcb353dbd79EndPoint")
  public RESTEndpoint activityFormNew_frmServiceEndPoint(ActivityFormNew_frmService activityFormNew_frmService) {
    return new RESTEndpoint("/gsp/myapp/v1.0/activityformnew_frm",activityFormNew_frmService);
  }
}
