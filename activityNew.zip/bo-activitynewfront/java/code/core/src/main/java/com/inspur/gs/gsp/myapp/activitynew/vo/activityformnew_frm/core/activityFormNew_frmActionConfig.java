package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core;

import com.inspur.edp.cef.entity.config.CefConfig;
import com.inspur.edp.cef.entity.config.CefExtendConfig;
import java.util.ArrayList;
import com.inspur.edp.bff.api.attribute.AbstractExtendActionConfig;
import com.inspur.edp.bff.api.manager.SourceConfig;
import com.inspur.edp.bff.api.attribute.AbstractSourceConfig;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityNewVoBizEntity;
import com.inspur.edp.cef.entity.entity.ICefData;
import com.fasterxml.jackson.core.JsonGenerator;
import com.inspur.edp.cef.entity.entity.IEntityData;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import java.lang.String;
import com.inspur.edp.cef.api.RefObject;
import java.lang.Boolean;
import java.util.HashMap;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.cef.spi.entity.AbstractDTEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmManager;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityNewBizEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityNewVoEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.IactivityNewView;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewChangeConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewDefaultValueMapConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityFormNew_frmDefaultValue;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityFormNew_frmActionConfig;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewFilterConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityFormNew_frmSourceConfig;
import com.inspur.edp.cef.api.attr.CefEntityAttribute;
import com.inspur.edp.cef.api.attr.CefDataAttribute;
import com.inspur.edp.bff.api.attribute.VMDataExtendAttribute;
import com.inspur.edp.bff.api.attribute.DataConvertorAttribute;
import com.inspur.edp.bff.api.attribute.ChangeConvertorAttribute;
import com.inspur.edp.bff.api.attribute.DefaultValueConvertorAttribute;
import com.inspur.edp.bff.api.attribute.ExtendActionAttribute;
import com.inspur.edp.cef.api.attr.VarConfigAttribute;
import com.inspur.edp.bff.api.attribute.FilterConvertorAttribute;
import com.inspur.edp.bff.api.attribute.SourceConfigAttribute;
import com.inspur.edp.bff.spi.AbstractFSManager;
import com.inspur.edp.cef.api.attr.ICefConfigCollection;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
public class activityFormNew_frmActionConfig extends AbstractExtendActionConfig {
  public activityFormNew_frmActionConfig(){
    java.util.ArrayList<java.lang.Class> types=null;
    types=new java.util.ArrayList<java.lang.Class>();
    BeforeQueryTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    QueryTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    AfterQueryTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    DataMapperTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    DataReversalMapperTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    BeforeRetrieveTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    RetrieveTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    AfterRetrieveTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    BeforeRetrieveDefaultTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    RetrieveDefaultTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    AfterRetrieveDefaultTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    BeforeModifyTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    ModifyTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    AfterModifyTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    BeforeDeleteTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    DeleteTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    AfterDeleteTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    BeforeMultiDeleteTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    MultiDeleteTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    AfterMultiDeleteTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    BeforeSaveTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    AfterSaveTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    ChangeMapperTypesField=types;
    types=new java.util.ArrayList<java.lang.Class>();
    ChangeReversalMapperTypesField=types;
  }
  @Override public java.util.ArrayList<java.lang.Class> getBeforeQueryTypes(){
    return BeforeQueryTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getQueryTypes(){
    return QueryTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getAfterQueryTypes(){
    return AfterQueryTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getDataMapperTypes(){
    return DataMapperTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getDataReversalMapperTypes(){
    return DataReversalMapperTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getBeforeRetrieveTypes(){
    return BeforeRetrieveTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getRetrieveTypes(){
    return RetrieveTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getAfterRetrieveTypes(){
    return AfterRetrieveTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getBeforeRetrieveDefaultTypes(){
    return BeforeRetrieveDefaultTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getRetrieveDefaultTypes(){
    return RetrieveDefaultTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getAfterRetrieveDefaultTypes(){
    return AfterRetrieveDefaultTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getBeforeModifyTypes(){
    return BeforeModifyTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getModifyTypes(){
    return ModifyTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getAfterModifyTypes(){
    return AfterModifyTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getBeforeDeleteTypes(){
    return BeforeDeleteTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getDeleteTypes(){
    return DeleteTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getAfterDeleteTypes(){
    return AfterDeleteTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getBeforeSaveTypes(){
    return BeforeSaveTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getAfterSaveTypes(){
    return AfterSaveTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getChangeMapperTypes(){
    return ChangeMapperTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getChangeReversalMapperTypes(){
    return ChangeReversalMapperTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getAfterMultiDeleteTypes(){
    return AfterMultiDeleteTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getBeforeMultiDeleteTypes(){
    return BeforeMultiDeleteTypesField;
  }
  @Override public java.util.ArrayList<java.lang.Class> getMultiDeleteTypes(){
    return MultiDeleteTypesField;
  }
  private ArrayList<java.lang.Class> BeforeQueryTypesField;
  private ArrayList<java.lang.Class> QueryTypesField;
  private ArrayList<java.lang.Class> AfterQueryTypesField;
  private ArrayList<java.lang.Class> DataMapperTypesField;
  private ArrayList<java.lang.Class> DataReversalMapperTypesField;
  private ArrayList<java.lang.Class> BeforeRetrieveTypesField;
  private ArrayList<java.lang.Class> RetrieveTypesField;
  private ArrayList<java.lang.Class> AfterRetrieveTypesField;
  private ArrayList<java.lang.Class> BeforeRetrieveDefaultTypesField;
  private ArrayList<java.lang.Class> RetrieveDefaultTypesField;
  private ArrayList<java.lang.Class> AfterRetrieveDefaultTypesField;
  private ArrayList<java.lang.Class> BeforeModifyTypesField;
  private ArrayList<java.lang.Class> ModifyTypesField;
  private ArrayList<java.lang.Class> AfterModifyTypesField;
  private ArrayList<java.lang.Class> BeforeDeleteTypesField;
  private ArrayList<java.lang.Class> DeleteTypesField;
  private ArrayList<java.lang.Class> AfterDeleteTypesField;
  private ArrayList<java.lang.Class> BeforeSaveTypesField;
  private ArrayList<java.lang.Class> AfterSaveTypesField;
  private ArrayList<java.lang.Class> ChangeMapperTypesField;
  private ArrayList<java.lang.Class> ChangeReversalMapperTypesField;
  private ArrayList<java.lang.Class> AfterMultiDeleteTypesField;
  private ArrayList<java.lang.Class> BeforeMultiDeleteTypesField;
  private ArrayList<java.lang.Class> MultiDeleteTypesField;
}

