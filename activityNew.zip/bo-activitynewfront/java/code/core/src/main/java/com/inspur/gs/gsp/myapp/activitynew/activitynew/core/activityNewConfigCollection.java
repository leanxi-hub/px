package com.inspur.gs.gsp.myapp.activitynew.activitynew.core;

import com.inspur.edp.cef.entity.config.CefConfig;
import com.inspur.edp.cef.entity.config.CefExtendConfig;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewBizEntity;
import com.inspur.edp.cef.api.determination.ICefDeterminationContext;
import com.inspur.edp.cef.spi.validation.IValidation;
import com.inspur.edp.cef.entity.changeset.IChangeDetail;
import com.inspur.edp.bef.builtincomponents.UQConstraints.UQConstraintValidator;
import com.inspur.edp.cef.api.validation.ICefValidationContext;
import com.inspur.edp.cef.entity.entity.ICefData;
import com.fasterxml.jackson.core.JsonGenerator;
import com.inspur.edp.cef.entity.entity.IEntityData;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import java.lang.String;
import com.inspur.edp.cef.api.RefObject;
import java.lang.Boolean;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewBEActionAssemblerFactory;
import com.inspur.edp.bef.api.be.IBEContext;
import com.inspur.edp.bef.api.parameter.retrieve.RetrieveParam;
import com.inspur.edp.bef.spi.action.assembler.entityAssemblerFactory.AbstractActionAssemblerFactory;
import com.inspur.edp.bef.spi.entity.CodeRuleInfo;
import java.util.HashMap;
import com.inspur.edp.bef.spi.entity.CodeRuleConfig;
import com.inspur.edp.cef.api.determination.attr.AfterCreateDtmsAttribute;
import com.inspur.edp.cef.api.determination.attr.AfterModifyDtmsAttribute;
import com.inspur.edp.cef.api.determination.attr.BeforeSaveDtmsAttribute;
import com.inspur.edp.cef.api.validation.attr.AfterModifyValsAttribute;
import com.inspur.edp.cef.api.validation.attr.BeforeSaveValsAttribute;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewBEManager;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewMgrActionAssemblerFactory;
import com.inspur.edp.bef.spi.action.assembler.mgrAssemblerFactory.MgrActionAssemblerFactory;
import com.inspur.edp.cef.spi.manager.IUQConstraintInfo;
import com.inspur.edp.cef.entity.UQConstraintConfig;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.core.activityNewBizEntity;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewEntity;
import com.inspur.edp.cef.api.attr.CefEntityAttribute;
import com.inspur.edp.cef.api.attr.CefDataAttribute;
import com.inspur.edp.bef.api.attr.AssemblerAttribute;
import com.inspur.edp.bef.api.attr.BeforeQueryDtmsAttribute;
import com.inspur.edp.bef.api.attr.BeforeRetrieveDtmsAttribute;
import com.inspur.edp.cef.api.attr.UQConstraintInfoAttribute;
import com.inspur.edp.cef.api.attr.VarConfigAttribute;
import com.inspur.edp.bef.spi.manager.AbstractManager;
import com.inspur.edp.cef.api.attr.ICefConfigCollection;
import java.util.ArrayList;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
public class activityNewConfigCollection implements ICefConfigCollection {
  public ArrayList<CefConfig> getConfigs(){
    java.util.ArrayList<CefConfig> list=new java.util.ArrayList<CefConfig>();
    com.inspur.edp.cef.entity.config.CefConfig config=new com.inspur.edp.cef.entity.config.CefConfig();
    config.setID("com.inspur.gs.gsp.myapp.activitynew.activityNew");
    config.setBEID("60cdf9cf-6180-4e7c-8d1e-a396b3e203f4");
    config.setDotnetID("Inspur.GS.Gsp.myapp.activityNew.activityNew");
    config.setSourceID("");
    config.setDefaultNamespace("com.inspur.gs.gsp.myapp.activitynew.activitynewgen");
    config.setMgrConfig(new com.inspur.edp.cef.entity.config.MgrConfig());
    config.getMgrConfig().setAssembly("com.inspur.gs.gsp.myapp.activitynew.activitynew.api");
    config.getMgrConfig().setClass("com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewBEManager");
    config.getMgrConfig().setImpClass("com.inspur.gs.gsp.myapp.activitynew.activitynew.core.activityNewBEManager");
    config.getMgrConfig().setAllInterfaceAssembly("com.inspur.gs.gsp.myapp.activitynew.activitynew.api");
    config.getMgrConfig().setAllInterfaceClassName("com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewService");
    config.setRepositoryConfig(new com.inspur.edp.cef.entity.config.RepositoryConfig());
    config.getRepositoryConfig().setAssembly("com.inspur.gs.gsp.myapp.activitynew.activitynew.core");
    config.getRepositoryConfig().setClass("com.inspur.gs.gsp.myapp.activitynew.activitynew.repository.activityNewRepoAssembler");
    list.add(config);
    return list;
  }
  public ArrayList<CefExtendConfig> getExtendConfigs(){
    java.util.ArrayList<com.inspur.edp.cef.entity.config.CefExtendConfig> list=new java.util.ArrayList<com.inspur.edp.cef.entity.config.CefExtendConfig>();
    return list;
  }
  public java.lang.String getConfigType(){
    return "BEF";
  }
}

