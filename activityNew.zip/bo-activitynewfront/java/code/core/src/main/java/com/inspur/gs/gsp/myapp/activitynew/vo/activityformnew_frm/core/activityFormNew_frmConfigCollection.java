package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core;

import com.inspur.edp.cef.entity.config.CefConfig;
import com.inspur.edp.cef.entity.config.CefExtendConfig;
import java.util.ArrayList;
import com.inspur.edp.bff.api.attribute.AbstractExtendActionConfig;
import com.inspur.edp.bff.api.manager.SourceConfig;
import com.inspur.edp.bff.api.attribute.AbstractSourceConfig;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityNewVoBizEntity;
import com.inspur.edp.cef.entity.entity.ICefData;
import com.fasterxml.jackson.core.JsonGenerator;
import com.inspur.edp.cef.entity.entity.IEntityData;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import java.lang.String;
import com.inspur.edp.cef.api.RefObject;
import java.lang.Boolean;
import java.util.HashMap;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.cef.spi.entity.AbstractDTEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmManager;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityNewBizEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityNewVoEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.IactivityNewView;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewChangeConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewDefaultValueMapConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityFormNew_frmDefaultValue;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityFormNew_frmActionConfig;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewFilterConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityFormNew_frmSourceConfig;
import com.inspur.edp.cef.api.attr.CefEntityAttribute;
import com.inspur.edp.cef.api.attr.CefDataAttribute;
import com.inspur.edp.bff.api.attribute.VMDataExtendAttribute;
import com.inspur.edp.bff.api.attribute.DataConvertorAttribute;
import com.inspur.edp.bff.api.attribute.ChangeConvertorAttribute;
import com.inspur.edp.bff.api.attribute.DefaultValueConvertorAttribute;
import com.inspur.edp.bff.api.attribute.ExtendActionAttribute;
import com.inspur.edp.cef.api.attr.VarConfigAttribute;
import com.inspur.edp.bff.api.attribute.FilterConvertorAttribute;
import com.inspur.edp.bff.api.attribute.SourceConfigAttribute;
import com.inspur.edp.bff.spi.AbstractFSManager;
import com.inspur.edp.cef.api.attr.ICefConfigCollection;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
public class activityFormNew_frmConfigCollection implements ICefConfigCollection {
  public ArrayList<CefConfig> getConfigs(){
    java.util.ArrayList<CefConfig> list=new java.util.ArrayList<CefConfig>();
    com.inspur.edp.cef.entity.config.CefConfig config=new com.inspur.edp.cef.entity.config.CefConfig();
    config.setID("com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm");
    config.setBEID("");
    config.setDotnetID("Inspur.GS.Gsp.myapp.activityNew.Vo.activityFormNew_frm");
    config.setSourceID("");
    config.setDefaultNamespace("com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frmgen");
    config.setMgrConfig(new com.inspur.edp.cef.entity.config.MgrConfig());
    config.getMgrConfig().setAssembly("com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api");
    config.getMgrConfig().setClass("com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmManager");
    config.getMgrConfig().setImpClass("com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityFormNew_frmVmManager");
    config.getMgrConfig().setAllInterfaceAssembly("com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api");
    config.getMgrConfig().setAllInterfaceClassName("com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmService");
    list.add(config);
    return list;
  }
  public ArrayList<CefExtendConfig> getExtendConfigs(){
    java.util.ArrayList<com.inspur.edp.cef.entity.config.CefExtendConfig> list=new java.util.ArrayList<com.inspur.edp.cef.entity.config.CefExtendConfig>();
    return list;
  }
  public java.lang.String getConfigType(){
    return "BFF";
  }
}

