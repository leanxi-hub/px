package com.inspur.gs.gsp.myapp.activitynew.activitynew.repository;

import com.inspur.edp.cef.repository.assembler.entity.MainEntityAssembler;
import java.util.ArrayList;
import com.inspur.edp.cef.entity.condition.SortCondition;
import com.inspur.edp.cef.entity.condition.FilterCondition;
public class activityNewRepoAssembler extends MainEntityAssembler {
  @Override protected boolean getIsFiscalTable(){
    return false;
  }
  @Override protected String getTableAlias(){
    return "activityNew";
  }
  @Override protected String getTableName(){
    return "GspactivityNew";
  }
  @Override public String getNodeCode(){
    return "activityNew";
  }
  @Override public MainEntityAssembler getParentAssembler(){
    return null;
  }
  @Override protected String getDboId(){
    return "11fd8e24-79e0-4c54-86c6-834947808d01";
  }
  @Override public boolean getUseDataCache(){
    return false;
  }
  @Override public String getCacheConfigID(){
    return "";
  }
  @Override public void initAssociationInfo(){
  }
  @Override public void initColumnInfo(){
    super.addColumn("ID","bb260a78-cff2-4fe4-8d22-7d644c6fbde8",com.inspur.edp.cef.repository.typetransprocesser.VarcharTransProcesser.getInstacne(),true,false,false,false,false,"ID",false);
    super.addColumn("Version","7697f843-f383-4ea8-9c9f-c77745826aea",com.inspur.edp.cef.repository.typetransprocesser.DateTimeTransProcesser.getInstacne(),false,false,false,false,false,"Version",false);
    super.addColumn("Code","cf45da71-ea5c-4414-82d1-489145d3f057",com.inspur.edp.cef.repository.typetransprocesser.VarcharTransProcesser.getInstacne(),false,false,false,false,false,"Code",false);
    super.addColumn("Title","ecb023e6-5157-4d0d-a4ec-d616470930bb",com.inspur.edp.cef.repository.typetransprocesser.VarcharTransProcesser.getInstacne(),false,false,false,false,false,"Title",false);
    super.addColumn("Location","569f15cb-9316-4e62-a2c6-75e0eb4985dc",com.inspur.edp.cef.repository.typetransprocesser.VarcharTransProcesser.getInstacne(),false,false,false,false,false,"Location",false);
    super.addColumn("GeoLng","c2cd35bd-9087-439d-a62a-c2cfa797bb9e",com.inspur.edp.cef.repository.typetransprocesser.DecimalTransProcesser.getInstacne(),false,false,false,false,false,"GeoLng",false);
    super.addColumn("GeoLat","6582ab2e-7306-417a-bc3b-6a60740bca94",com.inspur.edp.cef.repository.typetransprocesser.DecimalTransProcesser.getInstacne(),false,false,false,false,false,"GeoLat",false);
    super.addColumn("UpdateInfo","bb8161a7-f3d6-4fdb-a99b-bff1c725f1e6",com.inspur.edp.cef.repository.typetransprocesser.VarcharTransProcesser.getInstacne(),false,false,false,false,false,"UpdateInfo",false);
  }
  @Override protected ArrayList<SortCondition> getDefaultSortCondition(){
    return null;
  }
  @Override protected ArrayList<FilterCondition> getDefaultFilterCondition(){
    return null;
  }
}

