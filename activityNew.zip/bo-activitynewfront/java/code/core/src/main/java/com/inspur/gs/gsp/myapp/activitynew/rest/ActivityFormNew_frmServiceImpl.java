package com.inspur.gs.gsp.myapp.activitynew.rest;

import com.inspur.edp.sgf.api.service.InvokeService;
import java.lang.RuntimeException;
import javax.annotation.Resource;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.inspur.edp.sgf.base.VoBaseServiceImpl;
import java.lang.Exception;
import java.lang.RuntimeException;
import lombok.Data;
import java.util.Objects;
import com.inspur.edp.sgf.api.service.ServiceInvoker;
import com.inspur.edp.sgf.api.utils.EapiServiceUtils;
import com.inspur.edp.caf.transaction.api.annoation.GlobalTransactional;
import com.inspur.gs.gsp.myapp.activitynew.rest.ActivityFormNew_frmService;
import java.util.List;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.ArrayList;
import java.lang.String;
import java.lang.Object;

@Data
public class ActivityFormNew_frmServiceImpl extends VoBaseServiceImpl implements ActivityFormNew_frmService{

  protected String voId = "2a7d0ea5-55ef-4688-a7e2-2dcb353dbd79";

  protected String voCode = "com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm";



  @Override
  public Object createSession(){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&CreateSession",jsonNodes);
  }

  @Override
  public Object create(JsonNode node){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(EapiServiceUtils.getJsonNodeIgnoreCase("requestInfo",node));

      jsonNodes.add(EapiServiceUtils.getJsonNodeIgnoreCase("defaultValue",node));

    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&Create",jsonNodes);
  }

  @Override
  public Object edit(String dataId ,JsonNode node){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(node);
      jsonNodes.add(mapper.valueToTree(dataId));
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&Edit",jsonNodes);
  }

  @Override
  public void delete(String dataId ){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(mapper.valueToTree(dataId));
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&Delete",jsonNodes);
  }

  @Override
  public void batchDelete(String ids ){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(mapper.valueToTree(ids));
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&BatchDelete",jsonNodes);
  }

  @Override
  public Object update(JsonNode node){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(EapiServiceUtils.getJsonNodeIgnoreCase("requestInfo",node));

      jsonNodes.add(EapiServiceUtils.getJsonNodeIgnoreCase("changeDetail",node));

    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&Update",jsonNodes);
  }

  @Override
  public Object retrieve(String dataId ){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(mapper.valueToTree(dataId));
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&Retrieve",jsonNodes);
  }

  @Override
  public Object retrieveWithChildPagination(String dataId ,JsonNode node){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(EapiServiceUtils.getJsonNodeIgnoreCase("requestInfo",node));

      jsonNodes.add(mapper.valueToTree(dataId));
      jsonNodes.add(EapiServiceUtils.getJsonNodeIgnoreCase("retrieveParam",node));

    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&RetrieveWithChildPagination",jsonNodes);
  }

  @Override
  public Object queryChild(JsonNode node){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(EapiServiceUtils.getJsonNodeIgnoreCase("requestInfo",node));

      jsonNodes.add(EapiServiceUtils.getJsonNodeIgnoreCase("nodeCodes",node));

      jsonNodes.add(EapiServiceUtils.getJsonNodeIgnoreCase("ids",node));

      jsonNodes.add(EapiServiceUtils.getJsonNodeIgnoreCase("pagination ",node));

    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&QueryChild",jsonNodes);
  }

  @Override
  public Object query(String entityFilter ){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(mapper.valueToTree(entityFilter));
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&Query",jsonNodes);
  }

  @Override
  public Object save(JsonNode node){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(node);
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&Save",jsonNodes);
  }

  @Override
  public void cancel(){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&Cancel",jsonNodes);
  }

  @Override
  public Object getElementHelp(String labelId ,String nodeCode ,String queryParam ){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(mapper.valueToTree(labelId));
      jsonNodes.add(mapper.valueToTree(nodeCode));
      jsonNodes.add(mapper.valueToTree(queryParam));
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&ElementHelp",jsonNodes);
  }

  @Override
  public Object extend_Delete(String dataId ,JsonNode node){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(node);
      jsonNodes.add(mapper.valueToTree(dataId));
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&Extend_Delete",jsonNodes);
  }

  @Override
  public Object extend_BatchDelete(String ids ,JsonNode node){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(node);
      jsonNodes.add(mapper.valueToTree(ids));
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&Extend_BatchDelete",jsonNodes);
  }

  @Override
  public Object extend_Retrieve(String dataId ,JsonNode node){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(node);
      jsonNodes.add(mapper.valueToTree(dataId));
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&Extend_Retrieve",jsonNodes);
  }

  @Override
  public Object extend_Query(String entityFilter ,JsonNode node){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(node);
      jsonNodes.add(mapper.valueToTree(entityFilter));
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&Extend_Query",jsonNodes);
  }

  @Override
  public Object extend_GetElementHelp(JsonNode node){
    ArrayList<JsonNode> jsonNodes=new ArrayList<JsonNode>();
    ObjectMapper mapper = new ObjectMapper();
    try{
      jsonNodes.add(EapiServiceUtils.getJsonNodeIgnoreCase("requestInfo",node));

      jsonNodes.add(EapiServiceUtils.getJsonNodeIgnoreCase("labelId",node));

      jsonNodes.add(EapiServiceUtils.getJsonNodeIgnoreCase("nodeCode",node));

      jsonNodes.add(EapiServiceUtils.getJsonNodeIgnoreCase("queryParam",node));

    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return ServiceInvoker.invokeByJsonNode("VO","com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm","adae5fde-3dec-47d5-8ca6-0099585875b7&^^&Extend_ElementHelp",jsonNodes);
  }

}