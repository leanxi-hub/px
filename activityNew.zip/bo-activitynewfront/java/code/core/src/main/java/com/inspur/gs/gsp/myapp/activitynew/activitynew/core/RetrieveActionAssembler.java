package com.inspur.gs.gsp.myapp.activitynew.activitynew.core;

import com.inspur.edp.cef.entity.config.CefConfig;
import com.inspur.edp.cef.entity.config.CefExtendConfig;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewBizEntity;
import com.inspur.edp.cef.api.determination.ICefDeterminationContext;
import com.inspur.edp.cef.spi.validation.IValidation;
import com.inspur.edp.cef.entity.changeset.IChangeDetail;
import com.inspur.edp.bef.builtincomponents.UQConstraints.UQConstraintValidator;
import com.inspur.edp.cef.api.validation.ICefValidationContext;
import com.inspur.edp.cef.entity.entity.ICefData;
import com.fasterxml.jackson.core.JsonGenerator;
import com.inspur.edp.cef.entity.entity.IEntityData;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import java.lang.String;
import com.inspur.edp.cef.api.RefObject;
import java.lang.Boolean;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewBEActionAssemblerFactory;
import com.inspur.edp.bef.api.be.IBEContext;
import com.inspur.edp.bef.api.parameter.retrieve.RetrieveParam;
import com.inspur.edp.bef.spi.action.assembler.entityAssemblerFactory.AbstractActionAssemblerFactory;
import com.inspur.edp.bef.spi.entity.CodeRuleInfo;
import java.util.HashMap;
import com.inspur.edp.bef.spi.entity.CodeRuleConfig;
import com.inspur.edp.cef.api.determination.attr.AfterCreateDtmsAttribute;
import com.inspur.edp.cef.api.determination.attr.AfterModifyDtmsAttribute;
import com.inspur.edp.cef.api.determination.attr.BeforeSaveDtmsAttribute;
import com.inspur.edp.cef.api.validation.attr.AfterModifyValsAttribute;
import com.inspur.edp.cef.api.validation.attr.BeforeSaveValsAttribute;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewBEManager;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewMgrActionAssemblerFactory;
import com.inspur.edp.bef.spi.action.assembler.mgrAssemblerFactory.MgrActionAssemblerFactory;
import com.inspur.edp.cef.spi.manager.IUQConstraintInfo;
import com.inspur.edp.cef.entity.UQConstraintConfig;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.core.activityNewBizEntity;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewEntity;
import com.inspur.edp.cef.api.attr.CefEntityAttribute;
import com.inspur.edp.cef.api.attr.CefDataAttribute;
import com.inspur.edp.bef.api.attr.AssemblerAttribute;
import com.inspur.edp.bef.api.attr.BeforeQueryDtmsAttribute;
import com.inspur.edp.bef.api.attr.BeforeRetrieveDtmsAttribute;
import com.inspur.edp.cef.api.attr.UQConstraintInfoAttribute;
import com.inspur.edp.cef.api.attr.VarConfigAttribute;
import com.inspur.edp.bef.spi.manager.AbstractManager;
import com.inspur.edp.cef.api.attr.ICefConfigCollection;
import java.util.ArrayList;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
public class RetrieveActionAssembler extends com.inspur.edp.bef.spi.action.assembler.retrieve.RetrieveActionAssembler {
  public RetrieveActionAssembler(  IBEContext arg0,  RetrieveParam arg1){
    super(arg0,arg1);
  }
}

