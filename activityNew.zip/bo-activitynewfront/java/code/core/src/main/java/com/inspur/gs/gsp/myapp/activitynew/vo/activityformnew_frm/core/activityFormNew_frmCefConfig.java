package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core;

import com.inspur.edp.cef.entity.config.CefConfig;
import com.inspur.edp.cef.entity.config.CefExtendConfig;
import java.util.ArrayList;
import com.inspur.edp.bff.api.attribute.AbstractExtendActionConfig;
import com.inspur.edp.bff.api.manager.SourceConfig;
import com.inspur.edp.bff.api.attribute.AbstractSourceConfig;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityNewVoBizEntity;
import com.inspur.edp.cef.entity.entity.ICefData;
import com.fasterxml.jackson.core.JsonGenerator;
import com.inspur.edp.cef.entity.entity.IEntityData;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import java.lang.String;
import com.inspur.edp.cef.api.RefObject;
import java.lang.Boolean;
import java.util.HashMap;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.cef.spi.entity.AbstractDTEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmManager;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityNewBizEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityNewVoEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.IactivityNewView;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewChangeConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewDefaultValueMapConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityFormNew_frmDefaultValue;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityFormNew_frmActionConfig;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewFilterConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityFormNew_frmSourceConfig;
import com.inspur.edp.cef.api.attr.CefEntityAttribute;
import com.inspur.edp.cef.api.attr.CefDataAttribute;
import com.inspur.edp.bff.api.attribute.VMDataExtendAttribute;
import com.inspur.edp.bff.api.attribute.DataConvertorAttribute;
import com.inspur.edp.bff.api.attribute.ChangeConvertorAttribute;
import com.inspur.edp.bff.api.attribute.DefaultValueConvertorAttribute;
import com.inspur.edp.bff.api.attribute.ExtendActionAttribute;
import com.inspur.edp.cef.api.attr.VarConfigAttribute;
import com.inspur.edp.bff.api.attribute.FilterConvertorAttribute;
import com.inspur.edp.bff.api.attribute.SourceConfigAttribute;
import com.inspur.edp.bff.spi.AbstractFSManager;
import com.inspur.edp.cef.api.attr.ICefConfigCollection;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration("com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm.config") public class activityFormNew_frmCefConfig {
  @Bean("com.inspur.gs.gsp.myapp.activitynew.vo.activityFormNew_frm") public ICefConfigCollection getConfig(){
    return new activityFormNew_frmConfigCollection();
  }
  @Bean("adae5fde-3dec-47d5-8ca6-0099585875b7") public ICefConfigCollection getConfigByMdId(){
    return getConfig();
  }
}

