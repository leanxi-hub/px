package com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core;

import com.inspur.edp.cef.entity.config.CefConfig;
import com.inspur.edp.cef.entity.config.CefExtendConfig;
import java.util.ArrayList;
import com.inspur.edp.bff.api.attribute.AbstractExtendActionConfig;
import com.inspur.edp.bff.api.manager.SourceConfig;
import com.inspur.edp.bff.api.attribute.AbstractSourceConfig;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityNewVoBizEntity;
import com.inspur.edp.cef.entity.entity.ICefData;
import com.fasterxml.jackson.core.JsonGenerator;
import com.inspur.edp.cef.entity.entity.IEntityData;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import java.lang.String;
import com.inspur.edp.cef.api.RefObject;
import java.lang.Boolean;
import java.util.HashMap;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.edp.cef.spi.entity.AbstractDTEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityFormNew_frmManager;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityNewBizEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.api.IactivityNewVoEntity;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.IactivityNewView;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewChangeConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewDefaultValueMapConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityFormNew_frmDefaultValue;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityFormNew_frmActionConfig;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.activityNewFilterConvertor;
import com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.core.activityFormNew_frmSourceConfig;
import com.inspur.edp.cef.api.attr.CefEntityAttribute;
import com.inspur.edp.cef.api.attr.CefDataAttribute;
import com.inspur.edp.bff.api.attribute.VMDataExtendAttribute;
import com.inspur.edp.bff.api.attribute.DataConvertorAttribute;
import com.inspur.edp.bff.api.attribute.ChangeConvertorAttribute;
import com.inspur.edp.bff.api.attribute.DefaultValueConvertorAttribute;
import com.inspur.edp.bff.api.attribute.ExtendActionAttribute;
import com.inspur.edp.cef.api.attr.VarConfigAttribute;
import com.inspur.edp.bff.api.attribute.FilterConvertorAttribute;
import com.inspur.edp.bff.api.attribute.SourceConfigAttribute;
import com.inspur.edp.bff.spi.AbstractFSManager;
import com.inspur.edp.cef.api.attr.ICefConfigCollection;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
public class activityNewSerItem extends AbstractEntitySerializerItem {
  @Override public void writeEntityBasicInfo(  JsonGenerator writer,  IEntityData data,  SerializerProvider serializer){
    com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.IactivityNewView entityData=(com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.IactivityNewView)data;
    writeString(writer,entityData.getID(),"ID",serializer);
    writeDateTime(writer,entityData.getVersion(),"Version",serializer);
    writeString(writer,entityData.getCode(),"Code",serializer);
    writeString(writer,entityData.getTitle(),"Title",serializer);
    writeString(writer,entityData.getLocation(),"Location",serializer);
    writeDecimal(writer,entityData.getGeoLng(),"GeoLng",serializer);
    writeDecimal(writer,entityData.getGeoLat(),"GeoLat",serializer);
    writeString(writer,entityData.getUpdateInfo(),"UpdateInfo",serializer);
  }
  @Override public boolean readEntityBasicInfo(  JsonParser reader,  DeserializationContext serializer,  IEntityData data,  String propertyName){
    com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.IactivityNewView entityData=(com.inspur.gs.gsp.myapp.activitynew.vo.activityformnew_frm.entity.IactivityNewView)data;
switch (propertyName) {
case "Version":
case "version":
      entityData.setVersion(readDateTime(reader));
    return true;
case "Code":
case "code":
  entityData.setCode(readString(reader));
return true;
case "Title":
case "title":
entityData.setTitle(readString(reader));
return true;
case "Location":
case "location":
entityData.setLocation(readString(reader));
return true;
case "GeoLng":
case "geoLng":
entityData.setGeoLng(readDecimal(reader));
return true;
case "GeoLat":
case "geoLat":
entityData.setGeoLat(readDecimal(reader));
return true;
case "UpdateInfo":
case "updateInfo":
entityData.setUpdateInfo(readString(reader));
return true;
}
return false;
}
@Override public boolean writeModifyPropertyJson(JsonGenerator writer,java.lang.String propertyName,java.lang.Object value,SerializerProvider serializer){
switch (propertyName) {
case "ID":
case "id":
writeString(writer,value,propertyName,serializer);
return true;
case "Version":
case "version":
writeDateTime(writer,value,propertyName,serializer);
return true;
case "Code":
case "code":
writeString(writer,value,propertyName,serializer);
return true;
case "Title":
case "title":
writeString(writer,value,propertyName,serializer);
return true;
case "Location":
case "location":
writeString(writer,value,propertyName,serializer);
return true;
case "GeoLng":
case "geoLng":
writeDecimal(writer,value,propertyName,serializer);
return true;
case "GeoLat":
case "geoLat":
writeDecimal(writer,value,propertyName,serializer);
return true;
case "UpdateInfo":
case "updateInfo":
writeString(writer,value,propertyName,serializer);
return true;
}
return false;
}
@Override public Object readModifyPropertyValue(JsonParser reader,DeserializationContext serializer,RefObject<String> propertyName,RefObject<Boolean> hasRead){
switch (propertyName.argvalue) {
case "ID":
case "id":
hasRead.argvalue=true;
propertyName.argvalue="ID";
return readString(reader);
case "Version":
case "version":
hasRead.argvalue=true;
propertyName.argvalue="Version";
return readDateTime(reader);
case "Code":
case "code":
hasRead.argvalue=true;
propertyName.argvalue="Code";
return readString(reader);
case "Title":
case "title":
hasRead.argvalue=true;
propertyName.argvalue="Title";
return readString(reader);
case "Location":
case "location":
hasRead.argvalue=true;
propertyName.argvalue="Location";
return readString(reader);
case "GeoLng":
case "geoLng":
hasRead.argvalue=true;
propertyName.argvalue="GeoLng";
return readDecimal(reader);
case "GeoLat":
case "geoLat":
hasRead.argvalue=true;
propertyName.argvalue="GeoLat";
return readDecimal(reader);
case "UpdateInfo":
case "updateInfo":
hasRead.argvalue=true;
propertyName.argvalue="UpdateInfo";
return readString(reader);
}
hasRead.argvalue=false;
return null;
}
@Override public HashMap<String,String> getTransferPropertyNameMap(){
HashMap<String,String> dic=new HashMap<String,String>();
dic.put("id","ID");
dic.put("version","Version");
dic.put("code","Code");
dic.put("title","Title");
dic.put("location","Location");
dic.put("geoLng","GeoLng");
dic.put("geoLat","GeoLat");
dic.put("updateInfo","UpdateInfo");
return dic;
}
}

