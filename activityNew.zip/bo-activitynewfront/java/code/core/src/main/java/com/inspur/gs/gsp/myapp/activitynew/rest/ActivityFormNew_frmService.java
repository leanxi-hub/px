package com.inspur.gs.gsp.myapp.activitynew.rest;

import com.inspur.edp.sgf.base.VoBaseService;
import com.inspur.edp.sgf.api.annotation.EapiService;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.ArrayList;
import java.lang.String;
import java.lang.Object;

@EapiService(id="2a7d0ea5-55ef-4688-a7e2-2dcb353dbd79",code="activityFormNew_frm")
@Path("/")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface ActivityFormNew_frmService extends VoBaseService {

  @POST
  @Path("/service/createsession")
  @Produces(MediaType.TEXT_PLAIN)
  public Object createSession();


  @POST
  @Path("/")
  public Object create(JsonNode node);


  @PUT
  @Path("/service/edit/{dataId}")
  public Object edit(@PathParam("dataId") String dataId ,JsonNode node);


  @DELETE
  @Path("/{dataId}")
  public void delete(@PathParam("dataId") String dataId );


  @DELETE
  @Path("/")
  public void batchDelete(@QueryParam("ids") String ids );


  @PATCH
  @Path("/")
  public Object update(JsonNode node);


  @GET
  @Path("/{dataId}")
  public Object retrieve(@PathParam("dataId") String dataId );


  @PUT
  @Path("/service/retrieve/{dataId}")
  public Object retrieveWithChildPagination(@PathParam("dataId") String dataId ,JsonNode node);


  @PUT
  @Path("/service/querychild")
  public Object queryChild(JsonNode node);


  @GET
  @Path("/")
  public Object query(@QueryParam("entityFilter") String entityFilter );


  @PUT
  @Path("/")
  public Object save(JsonNode node);


  @POST
  @Path("/service/cancel")
  public void cancel();


  @GET
  @Path("/elementhelps/{labelId}")
  public Object getElementHelp(@PathParam("labelId") String labelId ,@QueryParam("nodeCode") String nodeCode ,@QueryParam("queryParam") String queryParam );


  @PUT
  @Path("/extension/delete/{dataId}")
  public Object extend_Delete(@PathParam("dataId") String dataId ,JsonNode node);


  @PUT
  @Path("/extension/batchdelete")
  public Object extend_BatchDelete(@QueryParam("ids") String ids ,JsonNode node);


  @PUT
  @Path("/extension/retrieve/{dataId}")
  public Object extend_Retrieve(@PathParam("dataId") String dataId ,JsonNode node);


  @PUT
  @Path("/extension/query")
  public Object extend_Query(@QueryParam("entityFilter") String entityFilter ,JsonNode node);


  @PUT
  @Path("/extension/elementhelps")
  public Object extend_GetElementHelp(JsonNode node);


}