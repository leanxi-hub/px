package com.inspur.gs.gsp.myapp.activitynew.activitynew.core;

import com.inspur.edp.cef.entity.config.CefConfig;
import com.inspur.edp.cef.entity.config.CefExtendConfig;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewBizEntity;
import com.inspur.edp.cef.api.determination.ICefDeterminationContext;
import com.inspur.edp.cef.spi.validation.IValidation;
import com.inspur.edp.cef.entity.changeset.IChangeDetail;
import com.inspur.edp.bef.builtincomponents.UQConstraints.UQConstraintValidator;
import com.inspur.edp.cef.api.validation.ICefValidationContext;
import com.inspur.edp.cef.entity.entity.ICefData;
import com.fasterxml.jackson.core.JsonGenerator;
import com.inspur.edp.cef.entity.entity.IEntityData;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import java.lang.String;
import com.inspur.edp.cef.api.RefObject;
import java.lang.Boolean;
import com.inspur.edp.cef.spi.jsonser.entity.AbstractEntitySerializerItem;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewBEActionAssemblerFactory;
import com.inspur.edp.bef.api.be.IBEContext;
import com.inspur.edp.bef.api.parameter.retrieve.RetrieveParam;
import com.inspur.edp.bef.spi.action.assembler.entityAssemblerFactory.AbstractActionAssemblerFactory;
import com.inspur.edp.bef.spi.entity.CodeRuleInfo;
import java.util.HashMap;
import com.inspur.edp.bef.spi.entity.CodeRuleConfig;
import com.inspur.edp.cef.api.determination.attr.AfterCreateDtmsAttribute;
import com.inspur.edp.cef.api.determination.attr.AfterModifyDtmsAttribute;
import com.inspur.edp.cef.api.determination.attr.BeforeSaveDtmsAttribute;
import com.inspur.edp.cef.api.validation.attr.AfterModifyValsAttribute;
import com.inspur.edp.cef.api.validation.attr.BeforeSaveValsAttribute;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewBEManager;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewMgrActionAssemblerFactory;
import com.inspur.edp.bef.spi.action.assembler.mgrAssemblerFactory.MgrActionAssemblerFactory;
import com.inspur.edp.cef.spi.manager.IUQConstraintInfo;
import com.inspur.edp.cef.entity.UQConstraintConfig;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.core.activityNewBizEntity;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.IactivityNewEntity;
import com.inspur.edp.cef.api.attr.CefEntityAttribute;
import com.inspur.edp.cef.api.attr.CefDataAttribute;
import com.inspur.edp.bef.api.attr.AssemblerAttribute;
import com.inspur.edp.bef.api.attr.BeforeQueryDtmsAttribute;
import com.inspur.edp.bef.api.attr.BeforeRetrieveDtmsAttribute;
import com.inspur.edp.cef.api.attr.UQConstraintInfoAttribute;
import com.inspur.edp.cef.api.attr.VarConfigAttribute;
import com.inspur.edp.bef.spi.manager.AbstractManager;
import com.inspur.edp.cef.api.attr.ICefConfigCollection;
import java.util.ArrayList;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
public class activityNewSerItem extends AbstractEntitySerializerItem {
  @Override public void writeEntityBasicInfo(  JsonGenerator writer,  IEntityData data,  SerializerProvider serializer){
    com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew entityData=(com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew)data;
    writeString(writer,entityData.getID(),"ID",serializer);
    writeDateTime(writer,entityData.getVersion(),"Version",serializer);
    writeString(writer,entityData.getCode(),"Code",serializer);
    writeString(writer,entityData.getTitle(),"Title",serializer);
    writeString(writer,entityData.getLocation(),"Location",serializer);
    writeDecimal(writer,entityData.getGeoLng(),"GeoLng",serializer);
    writeDecimal(writer,entityData.getGeoLat(),"GeoLat",serializer);
    writeString(writer,entityData.getUpdateInfo(),"UpdateInfo",serializer);
  }
  @Override public boolean readEntityBasicInfo(  JsonParser reader,  DeserializationContext serializer,  IEntityData data,  String propertyName){
    com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew entityData=(com.inspur.gs.gsp.myapp.activitynew.activitynew.entity.IactivityNew)data;
switch (propertyName) {
case "Version":
case "version":
      entityData.setVersion(readDateTime(reader));
    return true;
case "Code":
case "code":
  entityData.setCode(readString(reader));
return true;
case "Title":
case "title":
entityData.setTitle(readString(reader));
return true;
case "Location":
case "location":
entityData.setLocation(readString(reader));
return true;
case "GeoLng":
case "geoLng":
entityData.setGeoLng(readDecimal(reader));
return true;
case "GeoLat":
case "geoLat":
entityData.setGeoLat(readDecimal(reader));
return true;
case "UpdateInfo":
case "updateInfo":
entityData.setUpdateInfo(readString(reader));
return true;
}
return false;
}
@Override public boolean writeModifyPropertyJson(JsonGenerator writer,java.lang.String propertyName,java.lang.Object value,SerializerProvider serializer){
switch (propertyName) {
case "ID":
case "id":
writeString(writer,value,propertyName,serializer);
return true;
case "Version":
case "version":
writeDateTime(writer,value,propertyName,serializer);
return true;
case "Code":
case "code":
writeString(writer,value,propertyName,serializer);
return true;
case "Title":
case "title":
writeString(writer,value,propertyName,serializer);
return true;
case "Location":
case "location":
writeString(writer,value,propertyName,serializer);
return true;
case "GeoLng":
case "geoLng":
writeDecimal(writer,value,propertyName,serializer);
return true;
case "GeoLat":
case "geoLat":
writeDecimal(writer,value,propertyName,serializer);
return true;
case "UpdateInfo":
case "updateInfo":
writeString(writer,value,propertyName,serializer);
return true;
}
return false;
}
@Override public Object readModifyPropertyValue(JsonParser reader,DeserializationContext serializer,RefObject<String> propertyName,RefObject<Boolean> hasRead){
switch (propertyName.argvalue) {
case "ID":
case "id":
hasRead.argvalue=true;
propertyName.argvalue="ID";
return readString(reader);
case "Version":
case "version":
hasRead.argvalue=true;
propertyName.argvalue="Version";
return readDateTime(reader);
case "Code":
case "code":
hasRead.argvalue=true;
propertyName.argvalue="Code";
return readString(reader);
case "Title":
case "title":
hasRead.argvalue=true;
propertyName.argvalue="Title";
return readString(reader);
case "Location":
case "location":
hasRead.argvalue=true;
propertyName.argvalue="Location";
return readString(reader);
case "GeoLng":
case "geoLng":
hasRead.argvalue=true;
propertyName.argvalue="GeoLng";
return readDecimal(reader);
case "GeoLat":
case "geoLat":
hasRead.argvalue=true;
propertyName.argvalue="GeoLat";
return readDecimal(reader);
case "UpdateInfo":
case "updateInfo":
hasRead.argvalue=true;
propertyName.argvalue="UpdateInfo";
return readString(reader);
}
hasRead.argvalue=false;
return null;
}
}

