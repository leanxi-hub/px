package com.inspur.gs.gsp.myapp.activitynew.activitynew.core.Variable;

import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.Variable.IactivityNewVariableentity;
import com.fasterxml.jackson.core.JsonGenerator;
import com.inspur.edp.cef.entity.entity.IValueObjData;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import java.lang.String;
import com.inspur.edp.cef.api.RefObject;
import java.lang.Boolean;
import com.inspur.edp.cef.spi.jsonser.valueobj.AbstractValueObjSerializer;
import com.inspur.edp.cef.api.determination.attr.AfterCreateDtmsAttribute;
import com.inspur.edp.cef.api.determination.attr.AfterModifyDtmsAttribute;
import com.inspur.edp.cef.api.determination.attr.BeforeSaveDtmsAttribute;
import com.inspur.edp.cef.spi.entity.AbstractDTValueObject;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.Variable.IactivityNewVariableVaribaleManager;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.core.Variable.activityNewVariableentity;
import com.inspur.gs.gsp.myapp.activitynew.activitynew.api.Variable.IactivityNewVariableAllEntityInterface;
import com.inspur.edp.cef.api.attr.CefEntityAttribute;
import com.inspur.edp.cef.api.attr.CefDataAttribute;
import com.inspur.edp.cef.spi.manager.AbstractValueObjectManager;
@AfterCreateDtmsAttribute(determinations={},belongingTypes={},childAssemblers={}) @AfterModifyDtmsAttribute(determinations={},belongingTypes={},childAssemblers={}) @BeforeSaveDtmsAttribute(determinations={},belongingTypes={},childAssemblers={}) public class activityNewVariableentity extends AbstractDTValueObject implements IactivityNewVariableentity {
}

